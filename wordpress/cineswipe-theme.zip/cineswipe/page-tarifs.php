<?php
/** Guide des tarifs (portage de tarifs.njk). */
if (!defined('ABSPATH')) { exit; }
get_header();
$c = cs_contenu();
$abos = array_values(array_filter($c['cartes'], function ($x) { return $x['type'] === 'abonnement'; }));
$nouvel_onglet = '<span class="sr-only"> (s\'ouvre dans un nouvel onglet)</span>';
?>
<section class="section tarifs" aria-labelledby="tarifs-titre">
  <div class="wrap wrap--narrow">
    <h1 id="tarifs-titre">Combien coûte une place de cinéma ?</h1>
    <p class="section__intro">Chaque prix de cette page a une source, un lien et une date. Un prix relevé il y a plus de <?php echo (int) $c['seuilFraicheur']; ?> jours est marqué « à revérifier ».</p>

    <?php if ($c['prixMoyens']) : ?>
    <h2>Prix moyens payés en France</h2>
    <div class="table-wrap">
    <table class="table-prix">
      <caption class="sr-only">Prix moyens d'une place de cinéma, d'après une enquête</caption>
      <thead><tr><th scope="col">Type de place</th><th scope="col">Prix</th><th scope="col">Source</th></tr></thead>
      <tbody>
      <?php foreach ($c['prixMoyens'] as $p) : ?>
        <tr>
          <th scope="row"><?php echo esc_html($p['libelle']); ?><?php if ($p['note']) : ?><br><span class="caption"><?php echo esc_html($p['note']); ?></span><?php endif; ?></th>
          <td class="price"><?php echo esc_html($p['montantFr']); ?></td>
          <td class="caption"><a href="<?php echo esc_url($p['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($p['sourceNom']); ?><?php echo $nouvel_onglet; ?></a>, consultée le <?php echo esc_html($p['dateFr']); ?> (<?php echo (int) $p['sources']; ?> source)</td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <p class="caption">Ce sont des moyennes : le prix de ton cinéma peut être différent. Les relevés cinéma par cinéma sont plus bas.</p>
    <?php endif; ?>

    <?php if ($abos) : ?>
    <h2>Abonnements</h2>
    <ul class="tarifs__abos">
      <?php foreach ($abos as $a) : ?>
      <li><strong><?php echo esc_html($a['nom']); ?></strong> : <span class="price"><?php echo esc_html($a['prixMensuelFr']); ?></span> par mois (<?php echo esc_html($a['circuit']); ?>). Relevé le <?php echo esc_html($a['dateFr']); ?>, <a href="<?php echo esc_url($a['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($a['sourceNom']); ?><?php echo $nouvel_onglet; ?></a>.</li>
      <?php endforeach; ?>
    </ul>
    <p><a class="btn btn--secondary" href="<?php echo esc_url(cs_url('/cartes/')); ?>">Calculer si une carte vaut le coup</a></p>
    <?php endif; ?>

    <h2>Relevés de l'équipe, cinéma par cinéma</h2>
    <?php if ($c['releves']) : ?>
    <div class="table-wrap">
    <table class="table-prix">
      <caption class="sr-only">Prix relevés par l'équipe dans chaque cinéma</caption>
      <thead><tr><th scope="col">Cinéma</th><th scope="col">Tarif</th><th scope="col">Prix</th><th scope="col">Relevé</th></tr></thead>
      <tbody>
      <?php foreach ($c['releves'] as $r) : ?>
        <tr>
          <th scope="row"><?php echo esc_html($r['cinema']); ?><?php if ($r['exemple']) : ?> <span class="chip chip--exemple">Exemple à remplacer</span><?php endif; ?></th>
          <td><?php echo esc_html($r['type']); ?></td>
          <td class="price"><?php echo esc_html($r['montantFr']); ?></td>
          <td class="caption"><?php echo esc_html($r['dateFr']); ?> <span class="fraicheur<?php echo $r['fraicheur']['ancien'] ? ' fraicheur--alerte' : ''; ?>">(<?php echo esc_html(mb_strtolower($r['fraicheur']['texte'])); ?><?php echo $r['fraicheur']['ancien'] ? ', à revérifier' : ''; ?>)</span>, <a href="<?php echo esc_url($r['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($r['sourceNom']); ?><?php echo $nouvel_onglet; ?></a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <p class="caption">Un relevé par cinéma et par type de tarif, le plus récent. Ils viennent des fiches des films de la sélection : la liste s'allonge chaque semaine.</p>
    <?php else : ?>
    <p>Les relevés cinéma par cinéma arrivent avec la première sélection.</p>
    <?php endif; ?>
    <p class="caption">Les tarifs peuvent changer : vérifie le prix affiché sur le site du cinéma avant de payer.</p>
  </div>
</section>
<?php get_footer(); ?>
