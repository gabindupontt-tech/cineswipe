<?php
/** Accueil : la sélection de la semaine (portage de index.njk). */
if (!defined('ABSPATH')) { exit; }
get_header();
$c = cs_contenu();
$sem = $c['courante'];
?>
<section class="hero">
  <div class="wrap hero__grid">
    <div class="hero__texte">
      <?php if ($sem) : ?><p class="chips"><span class="chip"><?php echo esc_html($sem['label']); ?></span></p><?php endif; ?>
      <h1><?php echo $sem ? esc_html(count($sem['films']) . ' films qui valent leur prix cette semaine') : 'Les films qui valent leur prix'; ?></h1>
      <p class="hero__intro">Pour chaque film, trois lignes : pour qui, le prix, pourquoi en salle. Le tarif est relevé et daté, la réservation se fait sur le site du cinéma.</p>
      <p class="hero__actions">
        <?php if ($sem) : ?><a class="btn btn--primary btn--large" href="#selection">Voir la sélection</a>
        <a class="btn btn--secondary btn--large" href="<?php echo esc_url(cs_url('/swipe/')); ?>">Trier en swipant</a>
        <?php else : ?><a class="btn btn--primary btn--large" href="#newsletter">Être prévenu de la première sélection</a><?php endif; ?>
      </p>
      <p class="note-manuscrite" aria-hidden="true">pas de compte à créer</p>
    </div>
    <div class="hero__deco" aria-hidden="true">
      <span class="bulle bulle--grande"></span>
      <span class="bulle bulle--moyenne"></span>
      <span class="bulle bulle--petite"></span>
    </div>
  </div>
  <?php cs_wave('sunk', 1); ?>
</section>

<?php if ($sem) : ?>
<section class="section section--sunk" id="selection" aria-labelledby="selection-titre">
  <div class="wrap">
    <h2 id="selection-titre">La sélection du <?php echo esc_html($sem['dateFr']); ?></h2>
    <p class="section__intro"><?php echo esc_html($sem['labelLong']); ?>.</p>
    <?php if ($sem['edito']) : ?><div class="prose prose--edito"><?php echo $sem['edito']; // phpcs:ignore WordPress.Security.EscapeOutput -- filtré par wp_kses_post ?></div><?php endif; ?>
    <div class="cards">
      <?php foreach ($sem['films'] as $i => $film) { cs_verdict_card($film, $i % 3 + 1); } ?>
    </div>
    <p class="section__cta">
      <a class="btn btn--primary" href="<?php echo esc_url(cs_url('/swipe/')); ?>">Trier ces films en swipant</a>
      <a class="btn btn--ghost" href="<?php echo esc_url(cs_url('/archives/')); ?>">Semaines précédentes</a>
    </p>
  </div>
</section>
<?php cs_wave('base', 2); ?>

<section class="section" aria-labelledby="lire-titre">
  <div class="wrap wrap--narrow">
    <h2 id="lire-titre">Comment lire un verdict</h2>
    <ul class="lire">
      <li><span class="label">Pour qui</span> Le public qui y trouvera son compte, pour choisir avec qui y aller.</li>
      <li><span class="label">Prix</span> Ce que ça coûte vraiment, avec le tarif relevé sur le site du cinéma, sa source et sa date.</li>
      <li><span class="label">Pourquoi en salle</span> Ce que la salle apporte que ton écran ne donne pas.</li>
    </ul>
    <p>Le bouton de réservation te renvoie vers la page du cinéma lui-même, dans un nouvel onglet.</p>
  </div>
</section>
<?php cs_wave('sunk', 1); ?>
<?php else : ?>
<section class="section section--sunk">
  <div class="wrap wrap--narrow">
    <h2>La première sélection arrive bientôt</h2>
    <p>Laisse ton adresse e-mail plus bas, tu seras prévenu.</p>
  </div>
</section>
<?php cs_wave('base', 2); ?>
<?php endif; ?>

<?php cs_newsletter($sem ? 'sunk' : 'base', 'accueil'); ?>
<?php get_footer(); ?>
