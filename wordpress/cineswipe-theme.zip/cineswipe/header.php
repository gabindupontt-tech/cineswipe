<?php
/** En-tête commun (portage de _includes/base.njk, partie haute). */
if (!defined('ABSPATH')) { exit; }
$cs_kind = cs_kind();
$cs_nav = [
    ['Sélection', '/', $cs_kind === 'home'],
    ['Articles', '/articles/', in_array($cs_kind, ['articles', 'article'], true)],
    ['Swipe', '/swipe/', $cs_kind === 'swipe'],
    ['Groupe', '/groupes/', $cs_kind === 'groupes'],
    ['Mes cartes', '/cartes/', $cs_kind === 'cartes'],
    ['À propos', '/a-propos/', $cs_kind === 'apropos'],
];
?><!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body class="<?php echo cs_bon_plan_page() ? 'has-bonplan' : ''; ?>" data-ga="<?php echo esc_attr(cs_ga4_id()); ?>" data-api="<?php echo esc_attr(cs_stats_endpoint()); ?>" data-seuil="<?php echo (int) cs_setting('stats_seuil', 30); ?>"<?php echo cs_stats_demo() ? ' data-demo="1"' : ''; ?> data-base="<?php echo esc_url(trailingslashit(home_url('/'))); ?>">
<?php wp_body_open(); ?>
  <a class="skip-link" href="#contenu">Aller au contenu</a>

  <header class="site-header">
    <div class="wrap site-header__inner">
      <a class="logo" href="<?php echo esc_url(cs_url('/')); ?>" aria-label="CinéSwipe, accueil">
        <img class="logo__signe" src="<?php echo esc_url(cs_asset('img/logo-signe.svg')); ?>" width="40" height="40" alt="">
        <span class="logo__mot">cinéswipe</span>
      </a>
      <nav class="site-nav" aria-label="Navigation principale">
        <ul>
          <?php foreach ($cs_nav as $n) : ?><li><a class="pill-link" href="<?php echo esc_url(cs_url($n[1])); ?>"<?php echo $n[2] ? ' aria-current="page"' : ''; ?>><?php echo esc_html($n[0]); ?></a></li><?php endforeach; ?>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenu" tabindex="-1">
