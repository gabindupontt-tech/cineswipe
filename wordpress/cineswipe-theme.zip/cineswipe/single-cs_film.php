<?php
/** Fiche film (portage de film.njk). */
if (!defined('ABSPATH')) { exit; }
get_header();
$c = cs_contenu();
$film = cs_courant();
if ($film) :
    $autres = [];
    foreach ($c['semaines'] as $s) {
        if ($s['id'] === $film['semaineId']) {
            foreach ($s['films'] as $f) { if ($f['slug'] !== $film['slug']) { $autres[] = $f; } }
        }
    }
    $nouvel = '<span class="sr-only"> (s\'ouvre dans un nouvel onglet)</span>';
    $texte_wa = $film['titre'] . ' : ' . $film['verdict']['pourQui'] . ' ' . $film['urlAbs'] . '?utm_source=partage&utm_medium=whatsapp&utm_campaign=film_share';
    $fr = $film['tarif']['fraicheur'];
?>
<article class="section film">
  <div class="wrap">
    <p class="film__retour"><a class="btn btn--ghost btn--small" href="<?php echo esc_url(cs_url($film['semaineUrl'])); ?>"><span aria-hidden="true">←</span> <?php echo esc_html($film['semaineLabel']); ?></a></p>

    <div class="film__grid">
      <div class="film__media">
        <?php cs_poster_html($film, '(min-width: 900px) 400px, 80vw', 2, true); cs_price_badge($film); ?>
        <?php if ($film['afficheCredit']) : ?><p class="caption film__credit">Affiche : <?php echo esc_html($film['afficheCredit']); ?></p><?php endif; ?>
      </div>

      <div class="film__texte">
        <?php cs_chips($film); ?>
        <h1><?php echo esc_html($film['titre']); ?></h1>
        <p class="film__meta">
          <?php echo $film['sortieFr'] ? 'Sortie le ' . esc_html($film['sortieFr']) : ''; ?><?php echo $film['realisateur'] ? ', de ' . esc_html($film['realisateur']) : ''; ?>.
          <?php echo $film['titreOriginal'] ? 'Titre original : ' . esc_html($film['titreOriginal']) . '.' : ''; ?>
        </p>
        <?php if ($film['resume']) : ?><p><?php echo esc_html($film['resume']); ?></p><?php endif; ?>

        <div class="verdict-card verdict-card--solo">
          <h2 class="sr-only">Le verdict en trois lignes</h2>
          <?php cs_verdict_lines($film); ?>
        </div>
        <?php if (cs_stats_endpoint() || cs_stats_demo()) : ?><p class="stat-film" id="stat-film" data-slug="<?php echo esc_attr($film['slug']); ?>" data-semaine="<?php echo esc_attr($film['semaineId']); ?>" hidden></p><?php endif; ?>

        <section class="tarif" aria-labelledby="tarif-titre">
          <h2 id="tarif-titre">Tarif constaté</h2>
          <p class="tarif__ligne"><span class="price tarif__montant"><?php echo esc_html($film['tarif']['montantFr']); ?></span> <span>tarif <?php echo esc_html($film['tarif']['type'] . ', ' . $film['tarif']['cinema']); ?></span></p>
          <p class="mon-prix" id="mon-prix" data-tarif-type="<?php echo esc_attr($film['tarif']['type']); ?>" data-montant="<?php echo esc_attr($film['tarif']['montant']); ?>" hidden></p>
          <p class="caption">Relevé le <?php echo esc_html($film['tarif']['dateFr']); ?><?php if ($fr) : ?> <span class="fraicheur<?php echo $fr['ancien'] ? ' fraicheur--alerte' : ''; ?>">(<?php echo esc_html(mb_strtolower($fr['texte'])); ?><?php echo $fr['ancien'] ? ', à revérifier' : ''; ?>)</span><?php endif; ?>. Source : <a href="<?php echo esc_url($film['tarif']['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($film['tarif']['sourceNom']); ?><?php echo $nouvel; ?></a>. Les tarifs peuvent changer : vérifie le prix affiché avant de payer.</p>
        </section>

        <p class="film__reserver">
          <a class="btn btn--primary btn--large" href="<?php echo esc_url($film['reservation']['url']); ?>" target="_blank" rel="noopener noreferrer"
             data-track="screening_click" data-film="<?php echo esc_attr($film['slug']); ?>" data-cinema="<?php echo esc_attr($film['reservation']['cinema']); ?>" data-semaine="<?php echo esc_attr($film['semaineId']); ?>">
            Réserver sur le site du cinéma<?php echo $nouvel; ?>
            <svg class="btn__icone" viewBox="0 0 20 20" width="20" height="20" aria-hidden="true" focusable="false"><path d="M5 15 15 5M7 5h8v8" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </a>
        </p>
        <p class="caption">Tu quittes CinéSwipe pour la page de réservation de <?php echo esc_html($film['reservation']['cinema']); ?>.</p>

        <p class="film__actions">
          <?php if ($film['bandeAnnonce']) : ?><a class="btn btn--ghost btn--small" href="<?php echo esc_url($film['bandeAnnonce']); ?>" target="_blank" rel="noopener noreferrer" data-track="trailer_click" data-film="<?php echo esc_attr($film['slug']); ?>" data-semaine="<?php echo esc_attr($film['semaineId']); ?>">Voir la bande-annonce<span class="sr-only"> de <?php echo esc_html($film['titre']); ?> (s'ouvre dans un nouvel onglet)</span></a><?php endif; ?>
          <a class="btn btn--secondary btn--small" href="<?php echo esc_url('https://wa.me/?text=' . rawurlencode($texte_wa)); ?>" target="_blank" rel="noopener noreferrer" data-track="film_share" data-methode="whatsapp" data-film="<?php echo esc_attr($film['slug']); ?>" data-semaine="<?php echo esc_attr($film['semaineId']); ?>">Envoyer au groupe<span class="sr-only"> par WhatsApp (s'ouvre dans un nouvel onglet)</span></a>
          <button class="btn btn--secondary btn--small" type="button" id="film-share" data-titre="<?php echo esc_attr($film['titre']); ?>" data-texte="<?php echo esc_attr($film['verdict']['pourQui']); ?>" data-url="<?php echo esc_attr($film['urlAbs'] . '?utm_source=partage&utm_medium=share&utm_campaign=film_share'); ?>" data-film="<?php echo esc_attr($film['slug']); ?>" data-semaine="<?php echo esc_attr($film['semaineId']); ?>" hidden>Partager</button>
        </p>

        <?php if ($film['projections']) : ?>
        <section class="ou-voir" aria-labelledby="ouvoir-titre">
          <h2 id="ouvoir-titre">Où le voir près de toi</h2>
          <div id="ou-voir-lieu" hidden></div>
          <ol class="seances__liste" id="ou-voir-liste">
            <?php foreach ($film['projections'] as $p) : $ci = $p['cinema']; ?>
            <li class="seance" data-circuit="<?php echo esc_attr($ci['circuit']); ?>" data-cinema="<?php echo esc_attr($p['cinemaId']); ?>" data-ville="<?php echo esc_attr($ci['ville']); ?>" data-lat="<?php echo esc_attr($ci['lat']); ?>" data-lng="<?php echo esc_attr($ci['lng']); ?>">
              <div class="seance__tete">
                <h3 class="seance__nom"><?php echo esc_html($ci['nom']); ?></h3>
                <span class="chip"><?php echo $ci['type'] === 'independant' ? 'Indépendant' : esc_html($ci['circuit'] ?: 'Circuit'); ?></span>
                <p class="seance__dist price" hidden></p>
              </div>
              <p class="caption seance__adresse"><a href="<?php echo esc_url($ci['osm']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($ci['adresse']); ?><span class="sr-only"> sur la carte OpenStreetMap (s'ouvre dans un nouvel onglet)</span></a></p>
              <?php if ($p['tarif']) : $t = $p['tarif']; ?><p class="caption">Tarif <?php echo esc_html($t['type']); ?> constaté ici : <span class="price"><?php echo esc_html($t['montantFr']); ?></span>, relevé le <?php echo esc_html($t['dateFr']); ?><?php if ($t['fraicheur']['ancien']) : ?> <span class="fraicheur fraicheur--alerte">(<?php echo esc_html(mb_strtolower($t['fraicheur']['texte'])); ?>, à revérifier)</span><?php endif; ?>. <a href="<?php echo esc_url($t['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($t['sourceNom']); ?><?php echo $nouvel; ?></a>.</p><?php endif; ?>
              <p><a class="btn btn--secondary btn--small" href="<?php echo esc_url($p['url']); ?>" target="_blank" rel="noopener noreferrer"
                    data-track="screening_click" data-film="<?php echo esc_attr($film['slug']); ?>" data-cinema="<?php echo esc_attr($ci['nom']); ?>" data-semaine="<?php echo esc_attr($film['semaineId']); ?>">
                <?php echo $p['urlFilm'] ? 'Voir les séances' : 'Site du cinéma'; ?><span class="sr-only"> de <?php echo esc_html($film['titre']); ?> chez <?php echo esc_html($ci['nom']); ?> (s'ouvre dans un nouvel onglet)</span></a><?php if (!$p['urlFilm']) : ?> <span class="caption">Cherche le film sur la page d'accueil du cinéma.</span><?php endif; ?></p>
            </li>
            <?php endforeach; ?>
          </ol>
          <p class="caption" id="ou-voir-note" aria-live="polite">Cinémas listés par la rédaction. Avec JavaScript, tu peux les classer par distance.</p>
          <p class="caption">Le tarif <?php echo esc_html($film['tarif']['type']); ?> de <?php echo esc_html($film['tarif']['montantFr']); ?> a été relevé chez <?php echo esc_html($film['tarif']['cinema']); ?>. Les autres cinémas peuvent avoir un autre prix : vérifie-le sur leur site avant de réserver.</p>
        </section>
        <?php endif; ?>

        <?php if ($film['maison']) : $mz = $film['maison']; ?>
        <section class="maison" aria-labelledby="maison-titre">
          <h2 id="maison-titre">Et à la maison ?</h2>
          <p class="caption">Si tu préfères attendre ou si la séance est trop chère cette semaine, voici de quoi regarder sans sortir. Sélection de la rédaction, pas une liste complète.</p>
          <ul class="maison__liste">
            <?php foreach ($mz['titres'] as $t) : ?>
            <li class="maison__titre"><span class="maison__nom"><?php echo esc_html($t['titre']); ?></span> <span class="chip"><?php echo esc_html($t['plateforme']); ?></span><br><span><?php echo esc_html($t['pourquoi']); ?></span></li>
            <?php endforeach; ?>
          </ul>
          <?php if ($mz['abonnement']) : $ab = $mz['abonnement']; ?><p>Pour comparer : un mois de <?php echo esc_html($ab['plateforme']); ?> coûte <span class="price"><?php echo esc_html($ab['montantFr']); ?></span> (relevé le <?php echo esc_html($ab['dateFr']); ?>, <a href="<?php echo esc_url($ab['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($ab['sourceNom']); ?><?php echo $nouvel; ?></a>).</p><?php endif; ?>
          <p class="caption">Disponibilité vérifiée le <?php echo esc_html($mz['verifieLe']); ?> sur <a href="<?php echo esc_url($mz['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($mz['sourceNom']); ?><?php echo $nouvel; ?></a>. Les catalogues changent : vérifie avant de t'abonner.</p>
        </section>
        <?php endif; ?>

        <?php if ($film['noteHtml']) : ?><div class="prose"><?php echo $film['noteHtml']; // phpcs:ignore WordPress.Security.EscapeOutput -- filtré par wp_kses_post ?></div><?php endif; ?>
      </div>
    </div>
  </div>
</article>

<script type="application/json" id="cartes-data"><?php echo cs_json(['cartes' => $c['cartes']]); ?></script>

<?php if ($autres) : ?>
<?php cs_wave('sunk', 1); ?>
<section class="section section--sunk" aria-labelledby="autres-titre">
  <div class="wrap">
    <h2 id="autres-titre">Les autres films de la semaine</h2>
    <div class="cards">
      <?php foreach ($autres as $i => $f) { cs_verdict_card($f, $i % 3 + 1); } ?>
    </div>
    <p class="section__cta"><a class="btn btn--primary" href="<?php echo esc_url(cs_url('/swipe/')); ?>">Trier la semaine en swipant</a></p>
  </div>
</section>
<?php endif;
endif;
get_footer();
