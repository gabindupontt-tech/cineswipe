<?php
/** Articles : liste par rubrique (portage de articles.njk). */
if (!defined('ABSPATH')) { exit; }
get_header();
$c = cs_contenu();
?>
<section class="section">
  <div class="wrap wrap--narrow">
    <h1>Les articles</h1>
    <p class="section__intro">Chaque chiffre a une source et une date. Quatre rubriques, une idée par article.</p>
    <?php foreach ($c['rubriques'] as $id => $r) :
      $liste = array_values(array_filter($c['articles'], function ($a) use ($id) { return $a['rubrique'] === $id; }));
      if (!$liste) { continue; } ?>
    <h2 id="<?php echo esc_attr($id); ?>"><?php echo esc_html($r['nom']); ?></h2>
    <p class="caption"><?php echo esc_html($r['intro']); ?></p>
    <ul class="archives">
      <?php foreach ($liste as $a) : ?><li><a class="week-link" href="<?php echo esc_url(cs_url($a['url'])); ?>"><span class="week-link__date"><?php echo esc_html($a['titre']); ?></span><span class="caption"><?php echo esc_html($a['auteur'] . ' · ' . $a['dateFr'] . ' · ' . $a['minutes'] . ' min' . ($a['enRelecture'] ? ' · en relecture' : '')); ?></span></a></li>
      <?php endforeach; ?>
    </ul>
    <?php endforeach; ?>
  </div>
</section>
<?php get_footer(); ?>
