<?php
/** Page introuvable (portage de 404.njk). */
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<section class="section">
  <div class="wrap wrap--narrow">
    <h1>Cette page n'existe pas</h1>
    <p>Le lien est peut-être ancien. La sélection de la semaine, elle, est à jour.</p>
    <p><a class="btn btn--primary" href="<?php echo esc_url(cs_url('/')); ?>">Retour à la sélection</a></p>
  </div>
</section>
<?php get_footer(); ?>
