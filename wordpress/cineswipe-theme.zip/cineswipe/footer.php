<?php
/** Pied de page commun (portage de _includes/base.njk, partie basse). */
if (!defined('ABSPATH')) { exit; }
$cs_mesure = cs_ga4_id() || cs_stats_endpoint();
?>
  </main>

  <footer class="site-footer">
    <div class="site-footer__wave" aria-hidden="true"><svg viewBox="0 0 1440 96" preserveAspectRatio="none" focusable="false"><path d="M0 30C150 70 270 70 420 36S690 4 840 36s300 60 600 6V96H0Z"/></svg></div>
    <div class="wrap site-footer__inner">
      <p class="site-footer__marque"><span class="logo__mot">cinéswipe</span><br><span class="caption"><?php echo esc_html(CS_SLOGAN); ?></span></p>
      <nav aria-label="Pied de page">
        <ul class="site-footer__liens">
          <li><a href="<?php echo esc_url(cs_url('/articles/')); ?>">Articles</a></li>
          <li><a href="<?php echo esc_url(cs_url('/tarifs/')); ?>">Guide des tarifs</a></li>
          <li><a href="<?php echo esc_url(cs_url('/archives/')); ?>">Archives</a></li>
          <li><a href="<?php echo esc_url(cs_url('/a-propos/')); ?>">À propos et sources</a></li>
          <li><a href="<?php echo esc_url(cs_url('/a-propos/#mentions-legales')); ?>">Mentions légales</a></li>
          <li><a href="<?php echo esc_url(cs_url('/a-propos/#confidentialite')); ?>">Confidentialité</a></li>
          <?php foreach (cs_reseaux() as $nom => $url) : ?><li><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($nom); ?><span class="sr-only"> (s'ouvre dans un nouvel onglet)</span></a></li><?php endforeach; ?>
          <?php if ($cs_mesure) : ?><li><button class="link-btn" type="button" data-consent-open>Gérer mes cookies</button></li><?php endif; ?>
        </ul>
      </nav>
    </div>
  </footer>

  <?php if ($cs_mesure) : ?>
  <div class="consent" id="consent" role="dialog" aria-labelledby="consent-titre" aria-describedby="consent-texte" hidden>
    <h2 class="consent__titre" id="consent-titre">On compte, mais seulement si tu es d'accord</h2>
    <p id="consent-texte"><?php
      echo cs_ga4_id() ? 'On mesure l\'audience avec Google Analytics' : '';
      echo (cs_ga4_id() && cs_stats_endpoint()) ? ' et ' : '';
      echo cs_stats_endpoint() ? 'on compte, sans te nommer, les films que tu gardes pour afficher des statistiques de la communauté' : '';
    ?>. Si tu refuses, rien n'est mesuré ni envoyé et le site fonctionne pareil. <a href="<?php echo esc_url(cs_url('/a-propos/#confidentialite')); ?>">En savoir plus</a>.</p>
    <div class="consent__actions">
      <button class="btn btn--secondary" type="button" data-consent="denied">Refuser</button>
      <button class="btn btn--primary" type="button" data-consent="granted">Accepter</button>
    </div>
  </div>
  <?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
