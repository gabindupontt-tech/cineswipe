<?php
/** Archives : les semaines précédentes (portage de archives.njk). */
if (!defined('ABSPATH')) { exit; }
get_header();
$c = cs_contenu();
?>
<section class="section">
  <div class="wrap wrap--narrow">
    <h1>Les semaines précédentes</h1>
    <?php if ($c['archives']) : ?>
    <ul class="archives">
      <?php foreach ($c['archives'] as $s) : ?>
      <li>
        <a class="week-link" href="<?php echo esc_url(cs_url($s['url'])); ?>">
          <span class="week-link__date"><?php echo esc_html($s['label']); ?></span>
          <span class="week-link__films"><?php echo esc_html(implode(' · ', array_map(function ($f) { return $f['titre']; }, $s['films']))); ?></span>
        </a>
      </li>
      <?php endforeach; ?>
    </ul>
    <?php else : ?>
    <p>Pas encore de semaine archivée : la première sélection est celle de <a href="<?php echo esc_url(cs_url('/')); ?>">l'accueil</a>.</p>
    <?php endif; ?>
  </div>
</section>
<?php get_footer(); ?>
