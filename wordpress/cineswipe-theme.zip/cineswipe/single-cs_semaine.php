<?php
/** Une semaine archivée (portage de semaine.njk). La semaine courante redirige vers l'accueil (voir inc/setup.php). */
if (!defined('ABSPATH')) { exit; }
get_header();
$semaine = cs_courant();
if ($semaine) : ?>
<section class="section section--sunk">
  <div class="wrap">
    <p><a class="btn btn--ghost btn--small" href="<?php echo esc_url(cs_url('/archives/')); ?>"><span aria-hidden="true">←</span> Toutes les semaines</a></p>
    <h1>La sélection du <?php echo esc_html($semaine['dateFr']); ?></h1>
    <p class="section__intro"><?php echo esc_html($semaine['labelLong']); ?>. Les tarifs ont été relevés à cette période, vérifie-les avant de réserver.</p>
    <?php if ($semaine['edito']) : ?><div class="prose prose--edito"><?php echo $semaine['edito']; // phpcs:ignore WordPress.Security.EscapeOutput -- filtré par wp_kses_post ?></div><?php endif; ?>
    <div class="cards">
      <?php foreach ($semaine['films'] as $i => $film) { cs_verdict_card($film, $i % 3 + 1); } ?>
    </div>
  </div>
</section>
<?php endif;
get_footer();
