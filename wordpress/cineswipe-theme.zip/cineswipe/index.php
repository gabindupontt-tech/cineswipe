<?php
/** Gabarit de secours : les pages du site ont leurs propres gabarits (front-page.php, page-*.php, single-cs_*.php). */
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<section class="section">
  <div class="wrap wrap--narrow prose">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <h1><?php the_title(); ?></h1>
      <?php the_content(); ?>
    <?php endwhile; else : ?>
      <h1>Rien à afficher ici</h1>
      <p><a href="<?php echo esc_url(cs_url('/')); ?>">Retour à la sélection</a>.</p>
    <?php endif; ?>
  </div>
</section>
<?php get_footer(); ?>
