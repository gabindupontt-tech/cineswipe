<?php
/** Article (portage de article.njk : 8 éléments du gabarit). */
if (!defined('ABSPATH')) { exit; }
get_header();
$c = cs_contenu();
$article = cs_courant();
if (!$article) { status_header(404); }
$suite = [];
if ($article) {
    foreach ($c['articles'] as $a) { if ($a['slug'] !== $article['slug'] && $a['rubrique'] === $article['rubrique']) { $suite[] = $a; } }
    foreach ($c['articles'] as $a) { if ($a['slug'] !== $article['slug'] && $a['rubrique'] !== $article['rubrique'] && count($suite) < 2) { $suite[] = $a; } }
}
if ($article) : ?>
<article class="section article">
  <div class="wrap wrap--narrow">
    <p class="article__rubrique"><a class="chip" href="<?php echo esc_url(cs_url('/articles/#' . $article['rubrique'])); ?>"><?php echo esc_html($article['rubriqueNom']); ?></a></p>
    <h1><?php echo esc_html($article['titre']); ?></h1>
    <p class="caption article__meta">Par <?php echo esc_html($article['auteur']); ?> · <?php echo esc_html($article['dateFr']); ?> · <?php echo (int) $article['minutes']; ?> min de lecture<?php echo $article['enRelecture'] ? ' · <strong>version en relecture</strong>' : ''; ?></p>

    <p class="article__reponse" id="reponse"><?php echo esc_html($article['reponse']); ?></p>

    <div class="prose article__corps"><?php echo $article['html']; // phpcs:ignore WordPress.Security.EscapeOutput -- filtré par wp_kses_post ?></div>

    <section class="article__sources" aria-labelledby="sources-titre">
      <h2 id="sources-titre">Sources</h2>
      <ol class="sources">
        <?php foreach ($article['sources'] as $s) : ?><li value="<?php echo (int) $s['n']; ?>"><?php echo esc_html($s['nom']); ?> : <a href="<?php echo esc_url($s['url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($s['url']); ?><span class="sr-only"> (s'ouvre dans un nouvel onglet)</span></a><?php echo $s['note'] ? ' (' . esc_html($s['note']) . ')' : ''; ?></li>
        <?php endforeach; ?>
      </ol>
    </section>
  </div>
</article>

<?php cs_newsletter('sunk', 'article'); ?>

<?php if ($suite) : ?>
<section class="section" aria-labelledby="suite-titre">
  <div class="wrap wrap--narrow">
    <h2 id="suite-titre">À lire ensuite</h2>
    <ul class="archives">
      <?php foreach ($suite as $a) : ?><li><a class="week-link" href="<?php echo esc_url(cs_url($a['url'])); ?>"><span class="week-link__date"><?php echo esc_html($a['titre']); ?></span><span class="caption"><?php echo esc_html($a['rubriqueNom'] . ' · ' . $a['minutes'] . ' min'); ?></span></a></li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>
<?php endif;
else : ?>
<section class="section"><div class="wrap wrap--narrow"><h1>Article introuvable</h1><p>Cet article n'est pas publié. <a href="<?php echo esc_url(cs_url('/articles/')); ?>">Voir les articles</a>.</p></div></section>
<?php endif;
get_footer();
