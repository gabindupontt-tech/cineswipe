<?php
/**
 * CinéSwipe : thème WordPress. Portage du site statique Eleventy (v4).
 *
 * inc/helpers.php     mise en forme en français, réglages
 * inc/fields.php      champs de saisie de l'administration
 * inc/types.php       films, cinémas, semaines, articles, cartes, prix, chiffres + contrôles avant publication
 * inc/settings.php    page Réglages
 * inc/content.php     calcul de tout ce que les pages affichent
 * inc/components.php  composants de la charte
 * inc/seo.php         balises du <head>, indexation, données structurées
 * inc/setup.php       pages du site, scripts, styles, adresses
 * inc/seed.php        import du contenu de départ (films, cinémas, articles du site d'origine)
 */
if (!defined('ABSPATH')) { exit; }

foreach (['helpers', 'fields', 'types', 'settings', 'content', 'components', 'seo', 'setup', 'seed'] as $cs_fichier) {
    require_once get_theme_file_path('inc/' . $cs_fichier . '.php');
}
unset($cs_fichier);
