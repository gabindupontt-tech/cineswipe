<?php
/** Mes cartes : simulateur de rentabilité des abonnements (portage de cartes.njk). */
if (!defined('ABSPATH')) { exit; }
get_header();
$c = cs_contenu();
$ref = $c['referenceCartes'];
?>
<section class="section cartes" aria-labelledby="cartes-titre">
  <div class="wrap wrap--narrow">
    <h1 id="cartes-titre">Ta carte cinéma vaut-elle le coup ?</h1>
    <?php if (!$c['cartes'] || !$ref) : ?>
      <p>Cette page sera disponible dès que l'équipe aura relevé les tarifs.</p>
    <?php else : ?>
    <p class="section__intro">Coche tes cartes : les fiches film afficheront ton prix. Puis compare le prix à la séance et l'abonnement selon le nombre de films que tu vois par mois.</p>

    <div class="cartes-app" id="cartes-app">
      <fieldset class="cartes-choix">
        <legend class="lieu__label">Mes cartes</legend>
        <?php foreach ($c['cartes'] as $carte) : ?>
        <label class="carte-choix"><input type="checkbox" data-carte="<?php echo esc_attr($carte['id']); ?>"> <span><?php echo esc_html($carte['nom']); ?><?php if ($carte['type'] === 'abonnement') : ?> <span class="caption">(<?php echo esc_html($carte['prixMensuelFr']); ?> par mois, <?php echo esc_html($carte['circuit']); ?>)</span><?php endif; ?></span></label>
        <?php endforeach; ?>
        <p class="caption">Rien n'est envoyé : tes cartes restent dans ce navigateur.</p>
      </fieldset>

      <div class="simu" id="simu">
        <h2>Le calcul</h2>
        <label class="lieu__label" for="simu-films">Films vus au cinéma par mois : <span id="simu-films-val" class="price">2</span></label>
        <input id="simu-films" type="range" min="0" max="8" step="0.5" value="2">
        <?php foreach ($c['cartes'] as $carte) : if ($carte['type'] !== 'abonnement') { continue; } ?>
        <div class="simu__abo" data-abo="<?php echo esc_attr($carte['id']); ?>" data-prix="<?php echo esc_attr($carte['prixMensuel']); ?>">
          <h3><?php echo esc_html($carte['nom']); ?></h3>
          <p class="simu__ligne">À la séance : <span class="price" data-seance></span> par mois. Abonnement : <span class="price"><?php echo esc_html($carte['prixMensuelFr']); ?></span> par mois.</p>
          <p class="simu__verdict" data-verdict aria-live="polite"></p>
          <p class="caption">Abonnement relevé le <?php echo esc_html($carte['dateFr']); ?> : <a href="<?php echo esc_url($carte['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($carte['sourceNom']); ?><span class="sr-only"> (s'ouvre dans un nouvel onglet)</span></a>.</p>
        </div>
        <?php endforeach; ?>
        <p class="caption">Prix de la place utilisé pour le calcul : <?php echo esc_html($ref['montantFr']); ?>. <?php echo esc_html($ref['libelle']); ?>. Source : <a href="<?php echo esc_url($ref['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($ref['sourceNom']); ?><span class="sr-only"> (s'ouvre dans un nouvel onglet)</span></a>, consultée le <?php echo esc_html($ref['dateFr']); ?>. <?php echo esc_html($ref['note']); ?> Calcul de l'équipe : prix mensuel de l'abonnement divisé par ce prix. Remplace-le par le prix de ton cinéma si tu le connais.</p>
        <label class="lieu__label" for="simu-prix">Prix de ta place (en euros)</label>
        <input class="lieu__champ" id="simu-prix" type="number" min="1" max="30" step="0.1" value="<?php echo esc_attr($ref['montant']); ?>" inputmode="decimal">
        <?php if (!empty($ref['entreesParAn'])) : $e = $ref['entreesParAn']; ?><p class="caption">Repère : les 15-24 ans qui vont au cinéma y sont allés <?php echo esc_html(str_replace('.', ',', (string) $e['valeur'])); ?> fois en moyenne sur l'année 2025, soit bien moins d'une fois par mois (<?php echo esc_html($e['sourceNom']); ?>, <a href="<?php echo esc_url($e['sourceUrl']); ?>" target="_blank" rel="noopener noreferrer">source<span class="sr-only"> (s'ouvre dans un nouvel onglet)</span></a>, consultée le <?php echo esc_html($e['dateFr']); ?>). <?php echo esc_html($e['note']); ?></p><?php endif; ?>
      </div>

      <p class="section__cta"><a class="btn btn--primary" href="<?php echo esc_url(cs_url('/')); ?>">Voir la sélection de la semaine</a> <a class="btn btn--ghost" href="<?php echo esc_url(cs_url('/tarifs/')); ?>">Guide des tarifs</a> <a class="btn btn--secondary" href="<?php echo esc_url(cs_url('/#newsletter')); ?>">Recevoir la sélection chaque semaine</a></p>
    </div>
    <noscript><p class="caption">Le calcul demande JavaScript. Le prix mensuel de chaque abonnement et le prix de la place sont indiqués ci-dessus.</p></noscript>
    <script type="application/json" id="cartes-data"><?php echo cs_json(['cartes' => $c['cartes'], 'reference' => ['montant' => $ref['montant']]]); ?></script>
    <?php endif; ?>
  </div>
</section>
<?php get_footer(); ?>
