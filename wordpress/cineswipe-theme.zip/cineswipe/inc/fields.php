<?php
/**
 * Mini-framework de champs : encadrés de saisie pour les films, cinémas, semaines, etc.
 * et page de réglages. Une définition de champ est un tableau :
 *   key, label, type (text, textarea, number, date, url, select, checkbox, post, repeater),
 *   help, options (select), step/min/max (number), post_type (post), fields (repeater), maxlength.
 * Les valeurs sont stockées dans les métadonnées "cs_<key>" (un répéteur = un tableau sérialisé).
 */
if (!defined('ABSPATH')) { exit; }

/** Registre : type de contenu => liste des champs. */
function cs_fields_registry($cpt = null, $fields = null) {
    static $reg = [];
    if ($cpt !== null && $fields !== null) { $reg[$cpt] = $fields; }
    return $cpt !== null && $fields === null ? ($reg[$cpt] ?? []) : $reg;
}

function cs_post_options($post_type) {
    static $cache = [];
    if (!isset($cache[$post_type])) {
        $posts = get_posts([
            'post_type' => $post_type, 'post_status' => 'publish', 'numberposts' => -1,
            'orderby' => 'title', 'order' => 'ASC', 'suppress_filters' => true,
        ]);
        $cache[$post_type] = [];
        foreach ($posts as $p) { $cache[$post_type][$p->post_name] = $p->post_title; }
    }
    return $cache[$post_type];
}

function cs_render_input($f, $valeur, $name, $id) {
    $type = $f['type'];
    $attr_ml = !empty($f['maxlength']) ? ' maxlength="' . (int) $f['maxlength'] . '"' : '';
    $ph = !empty($f['placeholder']) ? ' placeholder="' . esc_attr($f['placeholder']) . '"' : '';
    switch ($type) {
        case 'textarea':
            echo '<textarea class="large-text" rows="' . (int) ($f['rows'] ?? 3) . '" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '"' . $attr_ml . $ph . '>' . esc_textarea((string) $valeur) . '</textarea>';
            break;
        case 'number':
            $step = $f['step'] ?? 'any';
            $min = isset($f['min']) ? ' min="' . esc_attr($f['min']) . '"' : '';
            $max = isset($f['max']) ? ' max="' . esc_attr($f['max']) . '"' : '';
            echo '<input type="number" class="small-text" style="width:8em" step="' . esc_attr($step) . '"' . $min . $max . ' id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr((string) $valeur) . '">';
            break;
        case 'date':
            echo '<input type="date" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr((string) $valeur) . '">';
            break;
        case 'url':
            echo '<input type="url" class="large-text" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr((string) $valeur) . '" placeholder="https://..."' . '>';
            break;
        case 'select':
            echo '<select id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">';
            foreach ($f['options'] as $v => $l) {
                echo '<option value="' . esc_attr($v) . '"' . selected((string) $valeur, (string) $v, false) . '>' . esc_html($l) . '</option>';
            }
            echo '</select>';
            break;
        case 'post':
            echo '<select id="' . esc_attr($id) . '" name="' . esc_attr($name) . '"><option value="">(choisir)</option>';
            foreach (cs_post_options($f['post_type']) as $slug => $titre) {
                echo '<option value="' . esc_attr($slug) . '"' . selected((string) $valeur, (string) $slug, false) . '>' . esc_html($titre . ' (' . $slug . ')') . '</option>';
            }
            if ($valeur && !isset(cs_post_options($f['post_type'])[$valeur])) {
                echo '<option value="' . esc_attr($valeur) . '" selected>' . esc_html($valeur . ' (introuvable ou non publié)') . '</option>';
            }
            echo '</select>';
            break;
        case 'checkbox':
            echo '<label><input type="checkbox" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="1"' . checked((string) $valeur, '1', false) . '> ' . esc_html($f['check_label'] ?? 'Oui') . '</label>';
            break;
        default:
            echo '<input type="text" class="large-text" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr((string) $valeur) . '"' . $attr_ml . $ph . '>';
    }
}

function cs_render_field_row($f, $valeur, $prefix) {
    $name = $prefix . '[' . $f['key'] . ']';
    $id = 'cs_' . sanitize_key(str_replace(['[', ']'], '_', $name));
    echo '<tr><th scope="row"><label for="' . esc_attr($id) . '">' . esc_html($f['label']) . '</label></th><td>';
    if ($f['type'] === 'repeater') {
        $rows = is_array($valeur) ? array_values($valeur) : [];
        echo '<div class="cs-rep" data-name="' . esc_attr($name) . '">';
        echo '<div class="cs-rep__rows">';
        foreach ($rows as $i => $row) { cs_render_repeater_row($f, $row, $name, $i); }
        echo '</div>';
        echo '<template class="cs-rep__tpl">'; cs_render_repeater_row($f, [], $name, '__i__'); echo '</template>';
        echo '<p><button type="button" class="button cs-rep__add">' . esc_html($f['add_label'] ?? 'Ajouter une ligne') . '</button></p>';
        echo '</div>';
    } else {
        cs_render_input($f, $valeur, $name, $id);
    }
    if (!empty($f['help'])) { echo '<p class="description">' . wp_kses_post($f['help']) . '</p>'; }
    echo '</td></tr>';
}

function cs_render_repeater_row($f, $row, $name, $i) {
    echo '<div class="cs-rep__row"><table class="form-table cs-rep__table" role="presentation"><tbody>';
    foreach ($f['fields'] as $sf) {
        $sname = $name . '[' . $i . '][' . $sf['key'] . ']';
        $sid = 'cs_' . sanitize_key(str_replace(['[', ']'], '_', $sname));
        echo '<tr><th scope="row"><label for="' . esc_attr($sid) . '">' . esc_html($sf['label']) . '</label></th><td>';
        cs_render_input($sf, $row[$sf['key']] ?? '', $sname, $sid);
        if (!empty($sf['help'])) { echo '<p class="description">' . wp_kses_post($sf['help']) . '</p>'; }
        echo '</td></tr>';
    }
    echo '</tbody></table><p><button type="button" class="button-link-delete cs-rep__del">Supprimer cette ligne</button></p></div>';
}

function cs_render_fields($fields, $get_value, $prefix) {
    echo '<table class="form-table cs-table" role="presentation"><tbody>';
    foreach ($fields as $f) {
        if ($f['type'] === 'heading') { echo '<tr><td colspan="2"><h3 class="cs-h">' . esc_html($f['label']) . '</h3></td></tr>'; continue; }
        cs_render_field_row($f, call_user_func($get_value, $f), $prefix);
    }
    echo '</tbody></table>';
}

function cs_sanitize_scalar($f, $raw) {
    $raw = is_scalar($raw) ? wp_unslash((string) $raw) : '';
    switch ($f['type']) {
        case 'textarea': return sanitize_textarea_field($raw);
        case 'number':   $raw = str_replace(',', '.', trim($raw)); return is_numeric($raw) ? $raw + 0 : '';
        case 'date':     return cs_iso_date($raw) ?: '';
        case 'url':      $u = esc_url_raw(trim($raw)); return $u;
        case 'select':   return array_key_exists($raw, $f['options']) ? $raw : (string) array_key_first($f['options']);
        case 'checkbox': return $raw === '1' ? '1' : '';
        case 'post':     return sanitize_title($raw);
        default:         return sanitize_text_field($raw);
    }
}

function cs_sanitize_fields($fields, $input) {
    $out = [];
    foreach ($fields as $f) {
        if ($f['type'] === 'heading') { continue; }
        $raw = is_array($input) && array_key_exists($f['key'], $input) ? $input[$f['key']] : null;
        if ($f['type'] === 'repeater') {
            $rows = [];
            foreach ((is_array($raw) ? $raw : []) as $row) {
                if (!is_array($row)) { continue; }
                $clean = []; $vide = true;
                foreach ($f['fields'] as $sf) {
                    $v = cs_sanitize_scalar($sf, $row[$sf['key']] ?? '');
                    $clean[$sf['key']] = $v;
                    if ($v !== '' && $v !== null) { $vide = false; }
                }
                if (!$vide) { $rows[] = $clean; }
            }
            $out[$f['key']] = $rows;
        } else {
            $out[$f['key']] = cs_sanitize_scalar($f, $raw === null ? '' : $raw);
        }
    }
    return $out;
}

/** Lit un champ de contenu (méta) avec une valeur par défaut. */
function cs_meta($post_id, $key, $defaut = '') {
    $v = get_post_meta($post_id, 'cs_' . $key, true);
    return ($v === '' || $v === null || $v === false) ? $defaut : $v;
}

/** Enregistre l'encadré de saisie d'un type de contenu. */
function cs_add_meta_box($cpt, $titre, $fields) {
    cs_fields_registry($cpt, $fields);

    add_action('add_meta_boxes_' . $cpt, function () use ($cpt, $titre, $fields) {
        add_meta_box('cs_box_' . $cpt, $titre, function ($post) use ($fields) {
            wp_nonce_field('cs_save_' . $post->post_type, 'cs_nonce');
            cs_render_fields($fields, function ($f) use ($post) { return cs_meta($post->ID, $f['key'], $f['default'] ?? ''); }, 'cs_f');
        }, $cpt, 'normal', 'high');
    });

    add_action('save_post_' . $cpt, function ($post_id, $post) use ($cpt, $fields) {
        if (!isset($_POST['cs_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['cs_nonce'])), 'cs_save_' . $cpt)) { return; }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (!current_user_can('edit_post', $post_id)) { return; }
        $input = isset($_POST['cs_f']) ? wp_unslash($_POST['cs_f']) : [];
        $clean = cs_sanitize_fields($fields, $input);
        foreach ($clean as $k => $v) { update_post_meta($post_id, 'cs_' . $k, $v); }
        do_action('cs_after_save_' . $cpt, $post_id, $post);
    }, 10, 2);
}

/** Script d'administration : répéteurs (ajout / suppression de lignes) et un peu de style. */
add_action('admin_footer', function () {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen) { return; }
    $ok = (strpos((string) $screen->post_type, 'cs_') === 0) || strpos((string) $screen->id, 'cineswipe') !== false;
    if (!$ok) { return; }
    ?>
    <style>
      .cs-table > tbody > tr > th { width: 190px; }
      .cs-h { margin: 1.2em 0 0; padding-top: .8em; border-top: 1px solid #dcdcde; }
      .cs-rep__row { border: 1px solid #dcdcde; background: #f6f7f7; padding: 4px 12px; margin-bottom: 10px; }
      .cs-rep__table th { width: 150px; padding: 8px 10px 8px 0; }
      .cs-rep__table td { padding: 6px 0; }
      .cs-notice-ok { border-left: 4px solid #00a32a; background: #fff; padding: 8px 12px; }
    </style>
    <script>
    (function () {
      var compteur = Date.now();
      document.addEventListener('click', function (e) {
        var add = e.target.closest('.cs-rep__add');
        if (add) {
          var rep = add.closest('.cs-rep');
          var tpl = rep.querySelector('.cs-rep__tpl');
          var html = tpl.innerHTML.replace(/__i__/g, 'n' + (compteur++));
          rep.querySelector('.cs-rep__rows').insertAdjacentHTML('beforeend', html);
          return;
        }
        var del = e.target.closest('.cs-rep__del');
        if (del) { var row = del.closest('.cs-rep__row'); row.parentNode.removeChild(row); }
      });
    })();
    </script>
    <?php
});
