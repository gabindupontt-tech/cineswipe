<?php
/**
 * Balises de la page <head> (titre, description, canonique, Open Graph, données structurées) et indexation.
 * Portage de base.njk, src.11tydata.js et lib/seo.js.
 */
if (!defined('ABSPATH')) { exit; }

/** Type de page courant : home, swipe, groupes, cartes, tarifs, archives, articles, apropos, film, week, article, 404, autre. */
function cs_kind() {
    static $kind = null;
    if ($kind !== null) { return $kind; }
    if (is_404()) { return $kind = '404'; }
    if (is_singular('cs_film')) { return $kind = 'film'; }
    if (is_singular('cs_semaine')) { return $kind = 'week'; }
    if (is_singular('cs_article')) { return $kind = 'article'; }
    if (is_front_page()) { return $kind = 'home'; }
    if (is_page()) {
        $map = ['swipe' => 'swipe', 'groupes' => 'groupes', 'cartes' => 'cartes', 'tarifs' => 'tarifs', 'archives' => 'archives', 'articles' => 'articles', 'a-propos' => 'apropos'];
        $slug = get_post_field('post_name', get_queried_object_id());
        if (isset($map[$slug])) { return $kind = $map[$slug]; }
    }
    return $kind = 'autre';
}

function cs_pages_meta() {
    return [
        'home' => ['CinéSwipe : les films qui valent le prix', 'Chaque semaine, 3 à 5 films avec un verdict en trois lignes (pour qui, prix, pourquoi en salle), le tarif relevé et le lien pour réserver sur le site du cinéma.'],
        'swipe' => ['Swipe : trie les films de la semaine | CinéSwipe', 'Garde ou écarte chaque film de la semaine, puis envoie ta liste dans le groupe. Pas de compte : ta liste reste dans ton navigateur.'],
        'groupes' => ['Groupe : choisissez les films ensemble | CinéSwipe', 'Crée un groupe d\'amis, comparez vos tris de la semaine, voyez qui veut voir quoi et où aller ensemble. Sans compte.'],
        'cartes' => ['Mes cartes : ta carte cinéma est-elle rentable ? | CinéSwipe', 'Renseigne tes cartes et abonnements, et calcule à partir de combien de films par mois une carte illimitée devient rentable face à la place à l\'unité.'],
        'tarifs' => ['Tarifs cinéma étudiant : prix relevés et abonnements | CinéSwipe', 'Combien coûte une place de cinéma quand on est étudiant ? Prix moyens, abonnements et relevés cinéma par cinéma, avec source et date pour chaque prix.'],
        'archives' => ['Archives : les sélections précédentes | CinéSwipe', 'Les sélections hebdomadaires précédentes de CinéSwipe, avec les films retenus et leurs verdicts.'],
        'articles' => ['Articles : tarifs, cartes et sélection du cinéma étudiant | CinéSwipe', 'Les articles de CinéSwipe par rubrique : ce que coûte le cinéma pour un étudiant, comparaison avec le streaming, et la sélection de la semaine.'],
        'apropos' => ['À propos, méthode et sources | CinéSwipe', 'Qui fait CinéSwipe, comment les films sont choisis, d\'où viennent les tarifs, mentions légales et politique de confidentialité.'],
    ];
}

/** Le film ou la semaine ou l'article de la page courante (tableaux du contenu préparé). */
function cs_courant() {
    static $res = false;
    if ($res !== false) { return $res; }
    $res = null;
    $c = cs_contenu();
    $slug = get_post_field('post_name', get_queried_object_id());
    if (is_singular('cs_film')) { $res = $c['filmsParSlug'][$slug] ?? null; }
    elseif (is_singular('cs_semaine')) { $res = cs_semaine_par_id($slug); }
    elseif (is_singular('cs_article')) {
        foreach ($c['articles'] as $a) { if ($a['slug'] === $slug) { $res = $a; } }
    }
    return $res;
}

function cs_noindex() {
    $c = cs_contenu();
    $k = cs_kind();
    $cur = cs_courant();
    if ($k === 'home' || $k === 'swipe') { return !$c['courante'] || $c['courante']['exemple']; }
    if ($k === 'film') { return !$cur || $cur['exemple']; }
    if ($k === 'week') { return !$cur || $cur['exemple']; }
    if ($k === 'tarifs') { return $c['aDesExemples']; }
    if ($k === 'archives') { foreach ($c['archives'] as $s) { if ($s['exemple']) { return true; } } return false; }
    if ($k === 'article') { return !$cur || $cur['enRelecture']; }
    return $k === 'groupes' || $k === '404' || $k === 'autre';
}

function cs_bon_plan_page() {
    $c = cs_contenu();
    $k = cs_kind();
    $cur = cs_courant();
    if ($k === 'home' || $k === 'swipe') { return !empty($c['courante']['bonPlan']); }
    if ($k === 'film') { return $cur && ($cur['bonPlan'] || $cur['semaineBonPlan']); }
    if ($k === 'week') { return $cur && $cur['bonPlan']; }
    return false;
}

function cs_titre_page() {
    $k = cs_kind();
    $cur = cs_courant();
    $meta = cs_pages_meta();
    if (isset($meta[$k])) { return $meta[$k][0]; }
    if ($k === 'film' && $cur) { return $cur['titreSeo'] . ' | CinéSwipe'; }
    if ($k === 'week' && $cur) { return 'Sélection du ' . $cur['dateFr'] . ' | CinéSwipe'; }
    if ($k === 'article' && $cur) { return $cur['titre'] . ' | CinéSwipe'; }
    if ($k === '404') { return 'Page introuvable | CinéSwipe'; }
    return 'CinéSwipe';
}

function cs_description_page() {
    $k = cs_kind();
    $cur = cs_courant();
    $meta = cs_pages_meta();
    if (isset($meta[$k])) { return $meta[$k][1]; }
    if ($k === 'film' && $cur) { return $cur['description']; }
    if ($k === 'week' && $cur) { return 'Les films retenus par CinéSwipe pour la semaine du ' . $cur['dateFr'] . ' : verdict en trois lignes, tarif relevé et réservation.'; }
    if ($k === 'article' && $cur) { return $cur['description']; }
    return CS_SLOGAN;
}

const CS_SLOGAN = 'Les films qui valent le prix, et comment les réserver.';

function cs_url_canonique() {
    $k = cs_kind();
    if ($k === 'home') { return home_url('/'); }
    if (is_singular()) { return get_permalink(get_queried_object_id()); }
    return home_url('/');
}

/* --- Titre et robots --- */
add_filter('pre_get_document_title', 'cs_titre_page');
add_filter('wp_robots', function ($robots) {
    if (cs_noindex()) { $robots['noindex'] = true; $robots['follow'] = true; unset($robots['max-image-preview']); }
    return $robots;
});

/* --- Allège le <head> de WordPress : pas d'émoji, pas de flux, pas de lien inutile --- */
add_action('init', function () {
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'rel_canonical');
    remove_action('wp_head', 'wp_shortlink_wp_head');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'rest_output_link_wp_head');
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'feed_links', 2);
    remove_action('wp_head', 'feed_links_extra', 3);
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('wp_head', 'wp_site_icon', 99);
});

function cs_jsonld_blocs() {
    $k = cs_kind();
    $cur = cs_courant();
    $site = home_url('/');
    if ($k === 'home') { return [['@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => 'CinéSwipe', 'url' => $site, 'inLanguage' => 'fr-FR']]; }
    if ($k === 'film' && $cur && !$cur['exemple']) {
        $film = ['@context' => 'https://schema.org', '@type' => 'Movie', 'name' => $cur['titre'], 'url' => $cur['urlAbs'],
            'description' => $cur['resume'] ?: $cur['description'],
            'datePublished' => ($cur['categorie'] === 'reprise' && $cur['annee']) ? (string) $cur['annee'] : $cur['sortie']];
        if ($cur['titreOriginal']) { $film['alternateName'] = $cur['titreOriginal']; }
        if ($cur['poster']) { $film['image'] = $cur['poster']['og']; }
        if ($cur['genres']) { $film['genre'] = $cur['genres']; }
        if ($cur['realisateur']) { $film['director'] = ['@type' => 'Person', 'name' => $cur['realisateur']]; }
        if ($cur['duree']) { $film['duration'] = 'PT' . intdiv($cur['duree'], 60) . 'H' . ($cur['duree'] % 60) . 'M'; }
        $fil = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'CinéSwipe', 'item' => $site],
            ['@type' => 'ListItem', 'position' => 2, 'name' => $cur['titre'], 'item' => $cur['urlAbs']],
        ]];
        return [$film, $fil];
    }
    if ($k === 'article' && $cur && !$cur['enRelecture']) {
        $art = ['@context' => 'https://schema.org', '@type' => 'Article', 'headline' => $cur['titre'], 'description' => $cur['description'], 'url' => $cur['urlAbs'],
            'inLanguage' => 'fr-FR', 'author' => ['@type' => 'Person', 'name' => $cur['auteur']], 'publisher' => ['@type' => 'Organization', 'name' => 'CinéSwipe']];
        if ($cur['date']) { $art['datePublished'] = $cur['date']; $art['dateModified'] = $cur['date']; }
        $fil = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'CinéSwipe', 'item' => $site],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'Articles', 'item' => home_url('/articles/')],
            ['@type' => 'ListItem', 'position' => 3, 'name' => $cur['titre'], 'item' => $cur['urlAbs']],
        ]];
        return [$art, $fil];
    }
    return [];
}

add_action('wp_head', function () {
    $titre = cs_titre_page();
    $desc = cs_description_page();
    $url = cs_url_canonique();
    $k = cs_kind();
    $cur = cs_courant();
    $image = ($k === 'film' && $cur && $cur['poster']) ? $cur['poster']['og'] : cs_asset('img/og-default.png');
    $type = $k === 'film' ? 'video.movie' : ($k === 'article' ? 'article' : 'website');
    ?>
<meta name="description" content="<?php echo esc_attr($desc); ?>">
<link rel="canonical" href="<?php echo esc_url($url); ?>">
<?php if (cs_setting('search_console_verification', '')) : ?><meta name="google-site-verification" content="<?php echo esc_attr(cs_setting('search_console_verification')); ?>">
<?php endif; ?>
<meta name="color-scheme" content="light dark">
<meta name="theme-color" content="#fff5f1" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#1c1228" media="(prefers-color-scheme: dark)">
<meta property="og:site_name" content="CinéSwipe">
<meta property="og:locale" content="fr_FR">
<meta property="og:type" content="<?php echo esc_attr($type); ?>">
<meta property="og:title" content="<?php echo esc_attr($titre); ?>">
<meta property="og:description" content="<?php echo esc_attr($desc); ?>">
<meta property="og:url" content="<?php echo esc_url($url); ?>">
<meta property="og:image" content="<?php echo esc_url($image); ?>">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" type="image/svg+xml" href="<?php echo esc_url(cs_asset('img/logo-signe.svg')); ?>">
<link rel="preload" href="<?php echo esc_url(cs_asset('fonts/fredoka-latin-700-normal.woff2')); ?>" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="<?php echo esc_url(cs_asset('fonts/figtree-latin-400-normal.woff2')); ?>" as="font" type="font/woff2" crossorigin>
<script>document.documentElement.classList.add('js')</script>
<?php foreach (cs_jsonld_blocs() as $bloc) : ?><script type="application/ld+json"><?php echo cs_json($bloc); ?></script>
<?php endforeach;
}, 1);
