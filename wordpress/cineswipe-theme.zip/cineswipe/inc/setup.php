<?php
/**
 * Mise en place du thème : tailles d'affiches, scripts et styles, pages du site, adresses (permaliens),
 * accès aux pages protégées par un 404 propre.
 */
if (!defined('ABSPATH')) { exit; }

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);
    add_image_size('cs-poster-s', 320, 0, false);
    add_image_size('cs-poster-m', 640, 0, false);
});

/** Pages du site : slug => [titre]. Le gabarit de chaque page est fichier page-<slug>.php. */
function cs_pages_du_site() {
    return [
        'selection' => 'Sélection',
        'swipe' => 'Swipe',
        'groupes' => 'Groupe',
        'cartes' => 'Mes cartes',
        'tarifs' => 'Guide des tarifs',
        'archives' => 'Archives',
        'articles' => 'Articles',
        'a-propos' => 'À propos et sources',
    ];
}

/** Crée les pages manquantes, règle la page d'accueil et les adresses. Idempotent. */
function cs_ensure_pages() {
    $creees = [];
    foreach (cs_pages_du_site() as $slug => $titre) {
        $existe = get_page_by_path($slug, OBJECT, 'page');
        if ($existe) {
            if ($existe->post_status !== 'publish') { wp_update_post(['ID' => $existe->ID, 'post_status' => 'publish']); }
            continue;
        }
        $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => $titre, 'post_name' => $slug, 'post_content' => '']);
        if ($id && !is_wp_error($id)) { $creees[] = $slug; }
    }
    $accueil = get_page_by_path('selection', OBJECT, 'page');
    if ($accueil) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $accueil->ID);
    }
    if (!get_option('permalink_structure')) { update_option('permalink_structure', '/%postname%/'); }
    flush_rewrite_rules();
    return $creees;
}

add_action('after_switch_theme', function () {
    cs_ensure_pages();
});

/* ------------------ Styles et scripts ------------------ */
add_action('wp_enqueue_scripts', function () {
    // On garde la charte du site d'origine : pas de styles de blocs WordPress par-dessus.
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('global-styles');
    wp_dequeue_style('classic-theme-styles');

    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('cs-styles', cs_asset('css/styles.css'), [], $v . '.' . filemtime(get_theme_file_path('assets/css/styles.css')));

    $defer = ['strategy' => 'defer', 'in_footer' => true];
    $js = function ($handle, $fichier, $deps = []) use ($v, $defer) {
        wp_enqueue_script($handle, cs_asset('js/' . $fichier), $deps, $v . '.' . filemtime(get_theme_file_path('assets/js/' . $fichier)), $defer);
    };
    $js('cs-consent', 'consent.js');
    $js('cs-main', 'main.js', ['cs-consent']);

    $pages = [
        'swipe' => ['geo.js', 'stats.js', 'swipe.js'],
        'film' => ['geo.js', 'stats.js', 'cartes.js'],
        'cartes' => ['cartes.js'],
        'groupes' => ['geo.js', 'groupes.js'],
    ];
    $k = cs_kind();
    if (isset($pages[$k])) {
        $prec = 'cs-main';
        foreach ($pages[$k] as $f) {
            $h = 'cs-' . basename($f, '.js');
            $js($h, $f, [$prec]);
            $prec = $h;
        }
    }
}, 20);

/* Les types de contenu internes (cinémas, cartes...) n'ont pas de page publique : 404 s'ils sont visités. */
add_action('template_redirect', function () {
    if (is_singular('cs_film')) {
        $c = cs_contenu();
        $slug = get_post_field('post_name', get_queried_object_id());
        $publie = false;
        foreach ($c['films'] as $f) { if ($f['slug'] === $slug) { $publie = true; } }
        if (!$publie) { global $wp_query; $wp_query->set_404(); status_header(404); nocache_headers(); }
    } elseif (is_singular('cs_semaine')) {
        $c = cs_contenu();
        $slug = get_post_field('post_name', get_queried_object_id());
        if (!cs_semaine_par_id($slug)) { global $wp_query; $wp_query->set_404(); status_header(404); nocache_headers(); }
        elseif ($c['courante'] && $c['courante']['id'] === $slug) { wp_safe_redirect(home_url('/'), 301); exit; }
    }
});

/* Pas de pagination ni d'archives WordPress parasites. */
add_filter('redirect_canonical', function ($redirect, $requested) {
    return is_singular('cs_semaine') ? false : $redirect;
}, 10, 2);

/* Sitemap : sans les types internes ni les pages d'exemple. */
add_filter('wp_sitemaps_post_types', function ($types) {
    unset($types['cs_semaine']);
    return $types;
});
