<?php
/**
 * Types de contenu (films, cinémas, semaines, articles, cartes, prix moyens, chiffres de contexte),
 * encadrés de saisie et contrôles avant publication (portage de la validation de lib/contenu.js).
 */
if (!defined('ABSPATH')) { exit; }

const CS_RUBRIQUES = [
    'ca-vaut-le-prix' => ['nom' => 'Ça vaut le prix ?', 'intro' => 'Le verdict de la semaine : pour qui, combien, pourquoi en salle.'],
    'budget-cine'     => ['nom' => 'Budget ciné', 'intro' => 'Tarifs, cartes et calculs pour aller au cinéma sans se ruiner.'],
    'en-bande'        => ['nom' => 'En bande', 'intro' => 'Choisir et organiser une sortie à plusieurs.'],
    'sur-le-terrain'  => ['nom' => 'Sur le terrain', 'intro' => 'Les cinémas de Clermont-Ferrand, vus de l\'intérieur.'],
];
const CS_CATEGORIES = ['nouveau' => 'À l\'affiche', 'independant' => 'Indépendant', 'reprise' => 'Reprise'];
const CS_TYPES_CINEMA = ['circuit' => 'Circuit', 'independant' => 'Indépendant'];

function cs_labels($singulier, $pluriel, $feminin = false, $menu = null) {
    $nouveau = $feminin ? 'Nouvelle' : 'Nouveau';
    return [
        'name' => $pluriel, 'singular_name' => $singulier, 'menu_name' => $menu ?: $pluriel,
        'add_new' => $nouveau, 'add_new_item' => $nouveau . ' ' . strtolower($singulier),
        'edit_item' => 'Modifier : ' . strtolower($singulier), 'new_item' => $nouveau . ' ' . strtolower($singulier),
        'view_item' => 'Voir', 'search_items' => 'Rechercher', 'not_found' => 'Aucun élément', 'not_found_in_trash' => 'Rien dans la corbeille',
        'all_items' => $pluriel,
    ];
}

add_action('init', function () {
    $parent = 'edit.php?post_type=cs_film';

    register_post_type('cs_film', [
        'labels' => cs_labels('Film', 'Films', false, 'CinéSwipe'),
        'public' => true, 'has_archive' => false, 'show_in_rest' => false,
        'rewrite' => ['slug' => 'films', 'with_front' => false],
        'menu_icon' => 'dashicons-video-alt2', 'menu_position' => 21,
        'supports' => ['title', 'editor', 'thumbnail'],
    ]);
    register_post_type('cs_cinema', [
        'labels' => cs_labels('Cinéma', 'Cinémas'),
        'public' => false, 'show_ui' => true, 'show_in_menu' => $parent, 'show_in_rest' => false,
        'supports' => ['title'],
    ]);
    register_post_type('cs_semaine', [
        'labels' => cs_labels('Semaine', 'Semaines', true),
        'public' => true, 'has_archive' => false, 'show_ui' => true, 'show_in_menu' => $parent, 'show_in_rest' => false,
        'rewrite' => ['slug' => 'archives', 'with_front' => false],
        'supports' => ['title', 'editor'],
    ]);
    register_post_type('cs_article', [
        'labels' => cs_labels('Article', 'Articles'),
        'public' => true, 'has_archive' => false, 'show_ui' => true, 'show_in_menu' => $parent, 'show_in_rest' => false,
        'rewrite' => ['slug' => 'articles', 'with_front' => false],
        'supports' => ['title', 'editor'],
    ]);
    register_post_type('cs_carte', [
        'labels' => cs_labels('Carte de réduction', 'Cartes', true),
        'public' => false, 'show_ui' => true, 'show_in_menu' => $parent, 'show_in_rest' => false,
        'supports' => ['title', 'page-attributes'],
    ]);
    register_post_type('cs_prix', [
        'labels' => cs_labels('Prix moyen', 'Prix moyens'),
        'public' => false, 'show_ui' => true, 'show_in_menu' => $parent, 'show_in_rest' => false,
        'supports' => ['title', 'page-attributes'],
    ]);
    register_post_type('cs_chiffre', [
        'labels' => cs_labels('Chiffre de contexte', 'Chiffres de contexte'),
        'public' => false, 'show_ui' => true, 'show_in_menu' => $parent, 'show_in_rest' => false,
        'supports' => ['title', 'page-attributes'],
    ]);
});

/* ====================== Définition des champs ====================== */

$cs_champs_tarif = [
    ['key' => 'montant', 'label' => 'Montant (€)', 'type' => 'number', 'step' => '0.01', 'min' => '0'],
    ['key' => 'type', 'label' => 'Type de tarif', 'type' => 'text', 'maxlength' => 14, 'placeholder' => 'étudiant'],
    ['key' => 'source_nom', 'label' => 'Nom de la source', 'type' => 'text'],
    ['key' => 'source_url', 'label' => 'Lien de la source', 'type' => 'url'],
    ['key' => 'date', 'label' => 'Date du relevé', 'type' => 'date'],
];

add_action('init', function () use ($cs_champs_tarif) {
    cs_add_meta_box('cs_film', 'Fiche du film', [
        ['key' => 'categorie', 'label' => 'Catégorie', 'type' => 'select', 'options' => CS_CATEGORIES, 'help' => '« Indépendant » : cinéma indépendant ou petit distributeur. « Reprise » : film ancien qui ressort en salle (l\'année d\'origine devient obligatoire).'],
        ['key' => 'annee', 'label' => 'Année d\'origine', 'type' => 'number', 'step' => '1', 'help' => 'Obligatoire pour une reprise (ex. 1998).'],
        ['key' => 'sortie', 'label' => 'Date de sortie', 'type' => 'date'],
        ['key' => 'duree', 'label' => 'Durée (minutes)', 'type' => 'number', 'step' => '1', 'min' => '1'],
        ['key' => 'genres', 'label' => 'Genres', 'type' => 'text', 'help' => 'Séparés par des virgules : Drame, Historique.'],
        ['key' => 'realisateur', 'label' => 'Réalisateur', 'type' => 'text'],
        ['key' => 'titre_original', 'label' => 'Titre original', 'type' => 'text'],
        ['key' => 'resume', 'label' => 'Résumé', 'type' => 'textarea'],
        ['key' => 'bon_plan', 'label' => 'Bon plan', 'type' => 'checkbox', 'check_label' => 'Afficher la pastille « Bon plan »'],
        ['key' => 'exemple', 'label' => 'Fiche d\'exemple', 'type' => 'checkbox', 'check_label' => 'Fiche d\'exemple à remplacer (non indexée par Google)'],
        ['key' => 'bande_annonce', 'label' => 'Bande-annonce', 'type' => 'url', 'help' => 'Lien sortant vers la bande-annonce officielle. Aucune vidéo n\'est intégrée.'],
        ['type' => 'heading', 'label' => 'Le verdict en trois lignes (obligatoire)'],
        ['key' => 'verdict_pour_qui', 'label' => 'Pour qui', 'type' => 'textarea', 'rows' => 2, 'help' => '160 caractères conseillés au maximum.'],
        ['key' => 'verdict_prix', 'label' => 'Prix', 'type' => 'textarea', 'rows' => 2],
        ['key' => 'verdict_pourquoi', 'label' => 'Pourquoi en salle', 'type' => 'textarea', 'rows' => 2],
        ['type' => 'heading', 'label' => 'Tarif constaté (source et date obligatoires)'],
        ['key' => 'tarif_montant', 'label' => 'Montant (€)', 'type' => 'number', 'step' => '0.01', 'min' => '0'],
        ['key' => 'tarif_type', 'label' => 'Type de tarif', 'type' => 'text', 'maxlength' => 14, 'placeholder' => 'étudiant'],
        ['key' => 'tarif_cinema', 'label' => 'Cinéma du relevé', 'type' => 'text'],
        ['key' => 'tarif_source_nom', 'label' => 'Nom de la source', 'type' => 'text'],
        ['key' => 'tarif_source_url', 'label' => 'Lien de la source', 'type' => 'url'],
        ['key' => 'tarif_date', 'label' => 'Date du relevé', 'type' => 'date'],
        ['type' => 'heading', 'label' => 'Bouton de réservation'],
        ['key' => 'reservation_cinema', 'label' => 'Cinéma', 'type' => 'text', 'help' => 'Laisser vide pour reprendre le cinéma du tarif.'],
        ['key' => 'reservation_url', 'label' => 'Lien de réservation', 'type' => 'url'],
        ['type' => 'heading', 'label' => 'Où le voir : cinémas qui passent le film'],
        ['key' => 'projections', 'label' => 'Cinémas', 'type' => 'repeater', 'add_label' => 'Ajouter un cinéma', 'fields' => array_merge([
            ['key' => 'cinema', 'label' => 'Cinéma', 'type' => 'post', 'post_type' => 'cs_cinema'],
            ['key' => 'url', 'label' => 'Page du film chez ce cinéma', 'type' => 'url', 'help' => 'Facultatif : sinon le bouton mène à la page d\'accueil du cinéma.'],
        ], array_map(function ($f) { $f['label'] = 'Tarif propre à ce cinéma : ' . lcfirst($f['label']); return $f; }, $cs_champs_tarif))],
        ['type' => 'heading', 'label' => 'Affiche (l\'image mise en avant se règle à droite)'],
        ['key' => 'affiche_alt', 'label' => 'Description de l\'affiche', 'type' => 'text', 'help' => 'Lue par les lecteurs d\'écran.'],
        ['key' => 'affiche_credit', 'label' => 'Crédit de l\'affiche', 'type' => 'text'],
        ['type' => 'heading', 'label' => 'Et à la maison ? (facultatif, 1 ou 2 titres)'],
        ['key' => 'maison_verifie_le', 'label' => 'Disponibilité vérifiée le', 'type' => 'date'],
        ['key' => 'maison_source_nom', 'label' => 'Source (nom)', 'type' => 'text'],
        ['key' => 'maison_source_url', 'label' => 'Source (lien)', 'type' => 'url'],
        ['key' => 'maison_t1_titre', 'label' => 'Titre 1', 'type' => 'text'],
        ['key' => 'maison_t1_plateforme', 'label' => 'Titre 1 : plateforme', 'type' => 'text'],
        ['key' => 'maison_t1_pourquoi', 'label' => 'Titre 1 : pourquoi', 'type' => 'text', 'maxlength' => 160],
        ['key' => 'maison_t2_titre', 'label' => 'Titre 2', 'type' => 'text'],
        ['key' => 'maison_t2_plateforme', 'label' => 'Titre 2 : plateforme', 'type' => 'text'],
        ['key' => 'maison_t2_pourquoi', 'label' => 'Titre 2 : pourquoi', 'type' => 'text', 'maxlength' => 160],
        ['key' => 'maison_abo_plateforme', 'label' => 'Abonnement : plateforme', 'type' => 'text'],
        ['key' => 'maison_abo_montant', 'label' => 'Abonnement : prix par mois (€)', 'type' => 'number', 'step' => '0.01'],
        ['key' => 'maison_abo_source_nom', 'label' => 'Abonnement : source (nom)', 'type' => 'text'],
        ['key' => 'maison_abo_source_url', 'label' => 'Abonnement : source (lien)', 'type' => 'url'],
        ['key' => 'maison_abo_date', 'label' => 'Abonnement : date du relevé', 'type' => 'date'],
        ['type' => 'heading', 'label' => 'Référencement'],
        ['key' => 'meta_description', 'label' => 'Description pour Google', 'type' => 'text', 'help' => 'Facultatif : sinon elle est composée à partir du verdict et du tarif.'],
    ]);

    cs_add_meta_box('cs_cinema', 'Fiche du cinéma', [
        ['key' => 'ville', 'label' => 'Ville', 'type' => 'text'],
        ['key' => 'adresse', 'label' => 'Adresse', 'type' => 'text', 'help' => 'Numéro, rue, code postal : elle s\'affiche à côté de la distance.'],
        ['key' => 'type', 'label' => 'Type', 'type' => 'select', 'options' => CS_TYPES_CINEMA],
        ['key' => 'circuit', 'label' => 'Circuit', 'type' => 'text', 'help' => 'Ex. UGC, Pathé, CGR. Le même mot que le champ « circuit » des cartes d\'abonnement.'],
        ['key' => 'lat', 'label' => 'Latitude', 'type' => 'number', 'step' => 'any', 'help' => 'Avec un point (ex. 45.7772). Clic droit sur le cinéma dans OpenStreetMap ou Google Maps. Le site n\'en invente aucune.'],
        ['key' => 'lng', 'label' => 'Longitude', 'type' => 'number', 'step' => 'any'],
        ['key' => 'site', 'label' => 'Site du cinéma', 'type' => 'url'],
        ['key' => 'exemple', 'label' => 'Exemple', 'type' => 'checkbox', 'check_label' => 'Cinéma d\'exemple (adresse fictive)'],
    ]);

    cs_add_meta_box('cs_semaine', 'Semaine', [
        ['key' => 'date', 'label' => 'Mercredi de début de semaine', 'type' => 'date', 'help' => 'La semaine n\'est publiée qu\'à partir de cette date : tu peux la préparer à l\'avance. Mets la même date dans l\'identifiant (adresse) de la page, par exemple 2026-10-28. Le texte ci-dessus est l\'éditorial.'],
        ['key' => 'films', 'label' => 'Films de la sélection (3 à 5)', 'type' => 'repeater', 'add_label' => 'Ajouter un film', 'fields' => [
            ['key' => 'film', 'label' => 'Film', 'type' => 'post', 'post_type' => 'cs_film'],
        ]],
        ['key' => 'en_plus', 'label' => 'Films en plus (indépendants, reprises, 6 maximum)', 'type' => 'repeater', 'add_label' => 'Ajouter un film en plus', 'fields' => [
            ['key' => 'film', 'label' => 'Film', 'type' => 'post', 'post_type' => 'cs_film'],
        ]],
    ]);

    cs_add_meta_box('cs_article', 'Article', [
        ['key' => 'numero', 'label' => 'Numéro (ordre)', 'type' => 'number', 'step' => '1'],
        ['key' => 'rubrique', 'label' => 'Rubrique', 'type' => 'select', 'options' => array_map(function ($r) { return $r['nom']; }, CS_RUBRIQUES)],
        ['key' => 'auteur', 'label' => 'Auteur', 'type' => 'text'],
        ['key' => 'reponse', 'label' => 'Réponse directe en tête', 'type' => 'textarea', 'rows' => 3, 'help' => 'Le paragraphe affiché en gras avant le corps de l\'article. Le texte principal est l\'éditeur ci-dessus (intertitres H2, renvois [1], [2] vers les sources).'],
        ['key' => 'meta_description', 'label' => 'Description pour Google', 'type' => 'text'],
        ['key' => 'prix_releves_le', 'label' => 'Prix relevés le', 'type' => 'date'],
        ['key' => 'relu_par', 'label' => 'Relu par', 'type' => 'text', 'help' => 'Vide : l\'article est publié en « noindex » avec la mention « en relecture ».'],
        ['key' => 'sources', 'label' => 'Sources (numérotées dans l\'ordre)', 'type' => 'repeater', 'add_label' => 'Ajouter une source', 'fields' => [
            ['key' => 'nom', 'label' => 'Nom', 'type' => 'text'],
            ['key' => 'url', 'label' => 'Lien', 'type' => 'url'],
            ['key' => 'note', 'label' => 'Note (ex. consulté le 26 octobre 2026)', 'type' => 'text'],
        ]],
    ]);

    cs_add_meta_box('cs_carte', 'Carte ou réduction', [
        ['key' => 'type', 'label' => 'Type', 'type' => 'select', 'options' => ['abonnement' => 'Abonnement (carte illimitée d\'un circuit)', 'reduction' => 'Réduction (tarif réduit)']],
        ['key' => 'circuit', 'label' => 'Circuit (abonnement)', 'type' => 'text', 'help' => 'Le même mot que le champ « circuit » des fiches cinéma (ex. UGC).'],
        ['key' => 'prix_mensuel', 'label' => 'Prix par mois (abonnement)', 'type' => 'number', 'step' => '0.01'],
        ['key' => 'tarif_type', 'label' => 'Type de tarif (réduction)', 'type' => 'text', 'maxlength' => 14, 'help' => 'Identique au « type de tarif » des fiches film (ex. étudiant).'],
        ['key' => 'source_nom', 'label' => 'Source (nom)', 'type' => 'text'],
        ['key' => 'source_url', 'label' => 'Source (lien)', 'type' => 'url'],
        ['key' => 'date', 'label' => 'Date du relevé', 'type' => 'date'],
    ]);

    cs_add_meta_box('cs_prix', 'Prix moyen', [
        ['key' => 'montant', 'label' => 'Montant (€)', 'type' => 'number', 'step' => '0.01'],
        ['key' => 'source_nom', 'label' => 'Source (nom)', 'type' => 'text'],
        ['key' => 'source_url', 'label' => 'Source (lien)', 'type' => 'url'],
        ['key' => 'date', 'label' => 'Date de consultation', 'type' => 'date'],
        ['key' => 'sources', 'label' => 'Nombre de sources indépendantes', 'type' => 'number', 'step' => '1', 'min' => '1', 'default' => 1],
        ['key' => 'note', 'label' => 'Note', 'type' => 'textarea', 'rows' => 2],
    ]);

    cs_add_meta_box('cs_chiffre', 'Chiffre de contexte', [
        ['key' => 'texte', 'label' => 'Texte', 'type' => 'textarea', 'rows' => 2, 'help' => 'Le titre ci-dessus est le chiffre lui-même (ex. 88 %).'],
        ['key' => 'source_nom', 'label' => 'Source (nom)', 'type' => 'text'],
        ['key' => 'source_url', 'label' => 'Source (lien)', 'type' => 'url'],
        ['key' => 'publie', 'label' => 'Publié le', 'type' => 'date'],
        ['key' => 'consulte', 'label' => 'Consulté le', 'type' => 'date'],
        ['key' => 'sources', 'label' => 'Nombre de sources indépendantes', 'type' => 'number', 'step' => '1', 'min' => '1', 'default' => 1],
        ['key' => 'calcul', 'label' => 'Calcul', 'type' => 'checkbox', 'check_label' => 'Chiffre calculé par l\'équipe à partir des sources citées'],
        ['key' => 'note', 'label' => 'Note', 'type' => 'textarea', 'rows' => 2],
    ]);
}, 5);

/* ====================== Contrôles avant publication ====================== */

/** Mémorise les erreurs et repasse le contenu en brouillon s'il était publié. */
function cs_bloquer_si_erreurs($post_id, $erreurs) {
    if (!$erreurs) { return; }
    set_transient('cs_err_' . $post_id . '_' . get_current_user_id(), $erreurs, 300);
    global $wpdb;
    $post = get_post($post_id);
    if ($post && in_array($post->post_status, ['publish', 'future'], true)) {
        $wpdb->update($wpdb->posts, ['post_status' => 'draft'], ['ID' => $post_id]);
        clean_post_cache($post_id);
    }
}

add_action('admin_notices', function () {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || strpos((string) $screen->post_type, 'cs_') !== 0 || empty($_GET['post'])) { return; }
    $id = (int) $_GET['post'];
    $erreurs = get_transient('cs_err_' . $id . '_' . get_current_user_id());
    if (!$erreurs) { return; }
    delete_transient('cs_err_' . $id . '_' . get_current_user_id());
    echo '<div class="notice notice-error"><p><strong>Contenu à corriger avant publication.</strong> Le contenu a été enregistré en brouillon.</p><ul style="list-style:disc;margin-left:1.5em">';
    foreach ($erreurs as $e) { echo '<li>' . esc_html($e) . '</li>'; }
    echo '</ul></div>';
});

function cs_slugs_publies($type) {
    return array_keys(cs_post_options($type));
}

add_action('cs_after_save_cs_film', function ($post_id, $post) {
    $e = [];
    $m = function ($k) use ($post_id) { return cs_meta($post_id, $k); };
    $titre = trim(get_the_title($post_id));
    if ($titre === '' || $titre === 'Brouillon auto') { $e[] = 'Le titre du film est vide.'; }
    if (!cs_iso_date($m('sortie'))) { $e[] = '« Date de sortie » doit être une date valide.'; }
    foreach (['verdict_pour_qui' => 'Pour qui', 'verdict_prix' => 'Prix', 'verdict_pourquoi' => 'Pourquoi en salle'] as $k => $l) {
        if (trim((string) $m($k)) === '') { $e[] = 'Verdict : la ligne « ' . $l . ' » est vide (les trois lignes sont obligatoires).'; }
    }
    if (!is_numeric($m('tarif_montant')) || $m('tarif_montant') <= 0) { $e[] = 'Tarif : le montant doit être un nombre positif (ex. 8.26).'; }
    $tt = (string) $m('tarif_type');
    if ($tt === '' || mb_strlen($tt) > 14) { $e[] = 'Tarif : le type est obligatoire et fait 14 caractères au maximum (ex. étudiant).'; }
    if ($m('tarif_cinema') === '') { $e[] = 'Tarif : le cinéma du relevé est vide.'; }
    if ($m('tarif_source_nom') === '') { $e[] = 'Tarif : le nom de la source est vide (un tarif sans source n\'est pas publiable).'; }
    if (!cs_est_https($m('tarif_source_url'))) { $e[] = 'Tarif : le lien de la source doit commencer par https://.'; }
    if (!cs_iso_date($m('tarif_date'))) { $e[] = 'Tarif : la date du relevé est obligatoire.'; }
    if (!cs_est_https($m('reservation_url'))) { $e[] = 'Réservation : le lien doit commencer par https://.'; }
    if ($m('duree') !== '' && (!is_numeric($m('duree')) || (int) $m('duree') <= 0)) { $e[] = 'La durée est un nombre entier de minutes.'; }
    $cat = $m('categorie', 'nouveau');
    $annee = $m('annee');
    if ($annee !== '' && (!is_numeric($annee) || $annee < 1895 || $annee > (int) cs_aujourdhui())) { $e[] = 'L\'année d\'origine doit tenir sur 4 chiffres (ex. 1998).'; }
    if ($cat === 'reprise' && $annee === '') { $e[] = 'Une reprise doit avoir une année d\'origine.'; }
    if ($m('bande_annonce') !== '' && !cs_est_https($m('bande_annonce'))) { $e[] = 'La bande-annonce doit être un lien complet en https://.'; }

    $cinemas = cs_slugs_publies('cs_cinema');
    $vus = [];
    foreach ((array) get_post_meta($post_id, 'cs_projections', true) as $i => $p) {
        $n = 'Cinéma ' . ($i + 1);
        $cid = $p['cinema'] ?? '';
        if ($cid === '' || !in_array($cid, $cinemas, true)) { $e[] = $n . ' : cinéma introuvable (il doit être publié dans « Cinémas »).'; continue; }
        if (in_array($cid, $vus, true)) { $e[] = $n . ' : le cinéma « ' . $cid . ' » est listé deux fois.'; continue; }
        $vus[] = $cid;
        if (($p['url'] ?? '') !== '' && !cs_est_https($p['url'])) { $e[] = $n . ' : le lien de la page du film doit commencer par https://.'; }
        $champs = ['montant', 'type', 'source_nom', 'source_url', 'date'];
        $presents = array_filter($champs, function ($k) use ($p) { return isset($p[$k]) && $p[$k] !== ''; });
        if ($presents && count($presents) < 5) { $e[] = $n . ' : un tarif propre à ce cinéma demande les cinq champs (montant, type, source, lien, date).'; }
        elseif ($presents) {
            if (!is_numeric($p['montant']) || $p['montant'] <= 0) { $e[] = $n . ' : montant invalide.'; }
            if (!cs_est_https($p['source_url'])) { $e[] = $n . ' : le lien de la source doit commencer par https://.'; }
        }
    }

    $maison_champs = ['verifie_le', 'source_nom', 'source_url', 't1_titre', 't2_titre', 'abo_plateforme'];
    $maison = array_filter($maison_champs, function ($k) use ($m) { return $m('maison_' . $k) !== ''; });
    if ($maison) {
        if (!cs_iso_date($m('maison_verifie_le'))) { $e[] = 'À la maison : la date de vérification est obligatoire.'; }
        if ($m('maison_source_nom') === '') { $e[] = 'À la maison : la source est vide.'; }
        if (!cs_est_https($m('maison_source_url'))) { $e[] = 'À la maison : le lien de la source doit commencer par https://.'; }
        $nb = 0;
        foreach (['t1', 't2'] as $t) {
            $a = [$m("maison_{$t}_titre"), $m("maison_{$t}_plateforme"), $m("maison_{$t}_pourquoi")];
            if (array_filter($a)) {
                $nb++;
                if (in_array('', $a, true)) { $e[] = 'À la maison : le titre ' . substr($t, 1) . ' demande titre, plateforme et pourquoi.'; }
            }
        }
        if ($nb < 1) { $e[] = 'À la maison : 1 ou 2 titres sont obligatoires.'; }
        if ($m('maison_abo_plateforme') !== '' || $m('maison_abo_montant') !== '') {
            if ($m('maison_abo_plateforme') === '' || !is_numeric($m('maison_abo_montant')) || $m('maison_abo_montant') <= 0 || $m('maison_abo_source_nom') === '' || !cs_est_https($m('maison_abo_source_url')) || !cs_iso_date($m('maison_abo_date'))) {
                $e[] = 'À la maison : l\'abonnement demande plateforme, prix, source, lien et date.';
            }
        }
    }
    cs_bloquer_si_erreurs($post_id, $e);
}, 10, 2);

add_action('cs_after_save_cs_cinema', function ($post_id) {
    $e = [];
    $m = function ($k) use ($post_id) { return cs_meta($post_id, $k); };
    if ($m('ville') === '') { $e[] = '« Ville » est vide.'; }
    if ($m('adresse') === '') { $e[] = '« Adresse » est vide.'; }
    $lat = $m('lat'); $lng = $m('lng');
    if (!is_numeric($lat) || !is_numeric($lng)) { $e[] = 'Latitude et longitude doivent être des nombres avec un point (ex. 45.7772 et 3.0870).'; }
    elseif ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) { $e[] = 'Latitude entre -90 et 90, longitude entre -180 et 180 : vérifie qu\'elles ne sont pas inversées.'; }
    if (!cs_est_https($m('site'))) { $e[] = 'Le site du cinéma doit être un lien complet en https://.'; }
    cs_bloquer_si_erreurs($post_id, $e);
});

add_action('cs_after_save_cs_semaine', function ($post_id) {
    $e = [];
    if (!cs_iso_date(cs_meta($post_id, 'date'))) { $e[] = '« Mercredi de début de semaine » doit être une date valide.'; }
    $films = cs_slugs_publies('cs_film');
    $tous = [];
    foreach (['films' => 'Sélection', 'en_plus' => 'En plus'] as $k => $l) {
        foreach ((array) get_post_meta($post_id, 'cs_' . $k, true) as $row) {
            $s = $row['film'] ?? '';
            if ($s === '' || !in_array($s, $films, true)) { $e[] = $l . ' : film introuvable ou non publié (« ' . $s . ' »).'; continue; }
            $tous[] = $s;
        }
    }
    if (!(array) get_post_meta($post_id, 'cs_films', true)) { $e[] = 'La sélection est vide : ajoute de 3 à 5 films.'; }
    if (count($tous) !== count(array_unique($tous))) { $e[] = 'Un film est listé deux fois.'; }
    cs_bloquer_si_erreurs($post_id, $e);
});

add_action('cs_after_save_cs_article', function ($post_id) {
    $e = [];
    $m = function ($k) use ($post_id) { return cs_meta($post_id, $k); };
    if (!isset(CS_RUBRIQUES[$m('rubrique')])) { $e[] = 'La rubrique est invalide.'; }
    if ($m('auteur') === '') { $e[] = '« Auteur » est vide.'; }
    if (trim((string) $m('reponse')) === '') { $e[] = 'La réponse directe en tête est vide.'; }
    if ($m('meta_description') === '') { $e[] = 'La description pour Google est vide.'; }
    if (!cs_iso_date($m('prix_releves_le'))) { $e[] = '« Prix relevés le » doit être une date valide.'; }
    $src = (array) get_post_meta($post_id, 'cs_sources', true);
    if (!$src) { $e[] = 'Au moins une source est obligatoire.'; }
    foreach ($src as $i => $s) {
        if (($s['nom'] ?? '') === '' || !cs_est_https($s['url'] ?? '')) { $e[] = 'Source ' . ($i + 1) . ' : nom et lien en https:// obligatoires.'; }
    }
    $corps = (string) get_post_field('post_content', $post_id);
    if (preg_match_all('/\[(\d+)\]/', $corps, $mm)) {
        foreach ($mm[1] as $n) { if ((int) $n < 1 || (int) $n > count($src)) { $e[] = 'Renvoi [' . $n . '] sans source correspondante.'; break; } }
    }
    cs_bloquer_si_erreurs($post_id, $e);
});

add_action('cs_after_save_cs_carte', function ($post_id) {
    $e = [];
    $m = function ($k) use ($post_id) { return cs_meta($post_id, $k); };
    if ($m('type') === 'abonnement') {
        if ($m('circuit') === '' || !is_numeric($m('prix_mensuel')) || $m('prix_mensuel') <= 0 || $m('source_nom') === '' || !cs_est_https($m('source_url')) || !cs_iso_date($m('date'))) {
            $e[] = 'Un abonnement demande circuit, prix par mois, source (nom et lien en https://) et date du relevé.';
        }
    } else {
        $t = (string) $m('tarif_type');
        if ($t === '' || mb_strlen($t) > 14) { $e[] = 'Une réduction demande un type de tarif (14 caractères maximum).'; }
    }
    cs_bloquer_si_erreurs($post_id, $e);
});

add_action('cs_after_save_cs_prix', function ($post_id) {
    $e = [];
    $m = function ($k) use ($post_id) { return cs_meta($post_id, $k); };
    if (!is_numeric($m('montant')) || $m('montant') <= 0 || $m('source_nom') === '' || !cs_est_https($m('source_url')) || !cs_iso_date($m('date'))) {
        $e[] = 'Un prix moyen demande un montant, une source (nom et lien en https://) et une date de consultation.';
    }
    cs_bloquer_si_erreurs($post_id, $e);
});

add_action('cs_after_save_cs_chiffre', function ($post_id) {
    $e = [];
    $m = function ($k) use ($post_id) { return cs_meta($post_id, $k); };
    if (trim(get_the_title($post_id)) === '') { $e[] = 'Le chiffre (titre) est vide.'; }
    if ($m('texte') === '') { $e[] = '« Texte » est vide.'; }
    if ($m('source_nom') === '') { $e[] = 'Un chiffre sans source n\'est pas publiable.'; }
    if (!cs_est_https($m('source_url'))) { $e[] = 'Le lien de la source doit commencer par https://.'; }
    if (!cs_iso_date($m('consulte'))) { $e[] = '« Consulté le » doit être la date où l\'équipe a ouvert la page.'; }
    if ($m('publie') !== '' && !cs_iso_date($m('publie'))) { $e[] = '« Publié le » doit être une date valide.'; }
    if (!is_numeric($m('sources')) || $m('sources') < 1) { $e[] = 'Le nombre de sources indépendantes est 1 ou plus.'; }
    cs_bloquer_si_erreurs($post_id, $e);
});

/* Masque l'éditeur de texte sur les types qui n'en ont pas besoin et ajoute des repères dans les listes. */
add_filter('enter_title_here', function ($t, $post) {
    $m = [
        'cs_film' => 'Titre du film', 'cs_cinema' => 'Nom du cinéma', 'cs_semaine' => 'Semaine du 28 octobre 2026',
        'cs_article' => 'Titre de l\'article', 'cs_carte' => 'Nom de la carte', 'cs_prix' => 'Type de place (ex. Plein tarif)',
        'cs_chiffre' => 'Le chiffre (ex. 88 %)',
    ];
    return $m[$post->post_type] ?? $t;
}, 10, 2);

/* Les semaines et les films gardent un identifiant d'adresse (slug) lisible : on l'affiche dans les listes. */
add_filter('manage_cs_semaine_posts_columns', function ($c) { $c['cs_date'] = 'Date de début'; return $c; });
add_action('manage_cs_semaine_posts_custom_column', function ($col, $id) {
    if ($col === 'cs_date') { echo esc_html(cs_date_fr(cs_meta($id, 'date'))); }
}, 10, 2);
add_filter('manage_cs_film_posts_columns', function ($c) { $c['cs_tarif'] = 'Tarif'; $c['cs_cat'] = 'Catégorie'; return $c; });
add_action('manage_cs_film_posts_custom_column', function ($col, $id) {
    if ($col === 'cs_tarif') {
        $mo = cs_meta($id, 'tarif_montant');
        echo $mo !== '' ? esc_html(cs_prix_fr($mo) . ' ' . cs_meta($id, 'tarif_type') . ', ' . cs_date_fr(cs_meta($id, 'tarif_date'))) : '';
    }
    if ($col === 'cs_cat') { echo esc_html(CS_CATEGORIES[cs_meta($id, 'categorie', 'nouveau')] ?? ''); }
}, 10, 2);
