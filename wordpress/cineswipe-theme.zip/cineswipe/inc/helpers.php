<?php
/**
 * Petites fonctions de mise en forme (français) : portage de lib/format.js.
 */
if (!defined('ABSPATH')) { exit; }

const CS_MOIS = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];

/** "2026-10-26" valide ? renvoie la chaîne ou null. */
function cs_iso_date($v) {
    $v = is_string($v) ? trim($v) : '';
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m)) { return null; }
    return checkdate((int) $m[2], (int) $m[3], (int) $m[1]) ? $v : null;
}

/** "2026-10-26" -> "26 octobre 2026" */
function cs_date_fr($iso, $avec_annee = true) {
    if (!$iso) { return ''; }
    list($a, $m, $j) = array_map('intval', explode('-', $iso));
    $jour = $j === 1 ? '1er' : (string) $j;
    return $jour . ' ' . CS_MOIS[$m - 1] . ($avec_annee ? ' ' . $a : '');
}

function cs_ajoute_jours($iso, $n) {
    $d = new DateTime($iso . ' 00:00:00', new DateTimeZone('UTC'));
    $d->modify(($n >= 0 ? '+' : '') . $n . ' days');
    return $d->format('Y-m-d');
}

function cs_aujourdhui() {
    return wp_date('Y-m-d', null, new DateTimeZone('Europe/Paris'));
}

/** 8.26 -> "8,26 €" */
function cs_prix_fr($n) {
    return number_format((float) $n, 2, ',', '') . "\u{00A0}€";
}

function cs_duree_fr($min) {
    $min = (int) $min;
    if ($min <= 0) { return ''; }
    $h = intdiv($min, 60);
    $m = $min % 60;
    return $h ? sprintf('%d h %02d', $h, $m) : $m . ' min';
}

function cs_tronque($texte, $max) {
    $t = trim(preg_replace('/\s+/u', ' ', (string) $texte));
    if (mb_strlen($t) <= $max) { return $t; }
    $coupe = mb_substr($t, 0, $max - 1);
    $pos = mb_strrpos($coupe, ' ');
    $coupe = $pos === false ? $coupe : mb_substr($coupe, 0, $pos);
    return preg_replace('/[,;:\-–]$/u', '', $coupe) . '…';
}

function cs_fin_de_phrase($t) {
    $s = trim((string) $t);
    return preg_match('/[.!?…]$/u', $s) ? $s : $s . '.';
}

function cs_est_https($u) {
    if (!is_string($u) || !preg_match('#^https://[^\s]+$#', $u)) { return false; }
    $h = wp_parse_url($u, PHP_URL_HOST);
    return $h && strpos($h, '.') !== false && strpos($h, '..') === false && $h[0] !== '.' && substr($h, -1) !== '.';
}

function cs_est_a_completer($v) {
    return is_string($v) && strpos($v, 'A_COMPLETER') === 0;
}

function cs_sans_a_completer($v) {
    return preg_replace('/^A_COMPLETER\s*:?\s*/', '', (string) $v);
}

/** Affiche un champ de réglage, en surlignant ceux qui restent à compléter. */
function cs_champ($v) {
    if (cs_est_a_completer($v)) {
        return '<mark class="a-completer">' . esc_html(cs_sans_a_completer($v)) . ' (à compléter)</mark>';
    }
    return esc_html($v);
}

/** JSON sûr à injecter dans un <script> (équivalent du filtre jsonSur). */
function cs_json($o) {
    $j = wp_json_encode($o, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $j = str_replace('<', '<', $j);
    return str_replace(["\u{2028}", "\u{2029}"], '', $j);
}

function cs_url($chemin = '/') {
    return home_url($chemin);
}

function cs_asset($chemin) {
    return get_theme_file_uri('assets/' . ltrim($chemin, '/'));
}

/** Réglages du site (équivalent de contenu/reglages.yml). */
function cs_setting($cle, $defaut = '') {
    $o = get_option('cs_settings', []);
    return (is_array($o) && isset($o[$cle]) && $o[$cle] !== '') ? $o[$cle] : $defaut;
}

function cs_ga4_id() {
    return trim((string) cs_setting('ga4_id', ''));
}

function cs_stats_endpoint() {
    return untrailingslashit(trim((string) cs_setting('stats_endpoint', '')));
}

function cs_stats_demo() {
    return (bool) cs_setting('stats_demo', '') && cs_stats_endpoint() === '';
}

function cs_lignes($texte) {
    $out = [];
    foreach (preg_split('/\R/u', (string) $texte) as $l) {
        $l = trim($l);
        if ($l !== '') { $out[] = $l; }
    }
    return $out;
}

/** Liens Instagram et TikTok renseignés (ni vides ni A_COMPLETER), pour le bloc newsletter et le pied de page. */
function cs_reseaux() {
    $r = [];
    foreach (['newsletter_instagram' => 'Instagram', 'newsletter_tiktok' => 'TikTok'] as $cle => $nom) {
        $v = cs_setting($cle, '');
        if ($v && !cs_est_a_completer($v)) { $r[$nom] = $v; }
    }
    return $r;
}
