<?php
/**
 * Réglages du site (équivalent de contenu/reglages.yml) : Réglages > CinéSwipe dans le menu, sous « CinéSwipe ».
 * Les champs qui commencent par A_COMPLETER sont signalés « à compléter » sur le site.
 */
if (!defined('ABSPATH')) { exit; }

function cs_settings_fields() {
    return [
        ['type' => 'heading', 'label' => 'Général'],
        ['key' => 'fraicheur_jours', 'label' => 'Fraîcheur des prix (jours)', 'type' => 'number', 'step' => '1', 'min' => '1', 'default' => 14, 'help' => 'Au-delà de ce nombre de jours depuis le relevé, la fiche affiche « à revérifier ». (H) 14 jours est une proposition de départ : à fixer par l\'équipe.'],
        ['type' => 'heading', 'label' => 'Mesure d\'audience (Google Analytics 4)'],
        ['key' => 'ga4_id', 'label' => 'Identifiant de mesure GA4', 'type' => 'text', 'placeholder' => 'G-ABC123XYZ4', 'help' => 'Vide : rien n\'est chargé et la bannière de consentement n\'apparaît pas.'],
        ['key' => 'search_console_verification', 'label' => 'Search Console : valeur de la balise', 'type' => 'text', 'help' => 'Seulement la valeur du champ content="..." (méthode « balise HTML »).'],
        ['type' => 'heading', 'label' => 'Newsletter'],
        ['key' => 'newsletter_lien', 'label' => 'Lien du bouton newsletter', 'type' => 'url'],
        ['key' => 'newsletter_lien_simule', 'label' => 'Lien simulé', 'type' => 'checkbox', 'check_label' => 'Ce lien est un exemple (affiche « Démonstration »)'],
        ['key' => 'newsletter_instagram', 'label' => 'Compte Instagram', 'type' => 'text'],
        ['key' => 'newsletter_tiktok', 'label' => 'Compte TikTok', 'type' => 'text'],
        ['type' => 'heading', 'label' => 'Page À propos et mentions légales'],
        ['key' => 'equipe_presentation', 'label' => 'Présentation de l\'équipe', 'type' => 'textarea', 'rows' => 4],
        ['key' => 'equipe_membres', 'label' => 'Membres de l\'équipe', 'type' => 'textarea', 'rows' => 5, 'help' => 'Un membre par ligne : « Prénom Nom, rôle ». Vérifie que chacun est d\'accord pour apparaître sur un site public.'],
        ['key' => 'methode_selection', 'label' => 'Méthode de sélection', 'type' => 'textarea', 'rows' => 4, 'help' => 'Écris ce que l\'équipe fait réellement.'],
        ['key' => 'editeur_nom', 'label' => 'Éditeur du site', 'type' => 'text'],
        ['key' => 'directeur_publication', 'label' => 'Directeur de la publication', 'type' => 'text', 'help' => 'Tant que le champ commence par A_COMPLETER, il est signalé « à compléter » sur le site.'],
        ['key' => 'contact_email', 'label' => 'E-mail de contact', 'type' => 'text'],
        ['key' => 'hebergeur_nom', 'label' => 'Hébergeur (nom)', 'type' => 'text'],
        ['key' => 'hebergeur_adresse', 'label' => 'Hébergeur (adresse)', 'type' => 'text', 'help' => 'À vérifier sur la documentation de l\'hébergeur avant publication.'],
        ['key' => 'credits_supplementaires', 'label' => 'Crédits supplémentaires', 'type' => 'textarea', 'rows' => 3, 'help' => 'Un par ligne (par exemple une base de données utilisée). Vide si les informations viennent uniquement des sites des cinémas et des distributeurs.'],
        ['type' => 'heading', 'label' => 'Prix de référence (page Mes cartes)'],
        ['key' => 'ref_montant', 'label' => 'Prix de la place (€)', 'type' => 'number', 'step' => '0.01'],
        ['key' => 'ref_libelle', 'label' => 'Libellé', 'type' => 'text'],
        ['key' => 'ref_source_nom', 'label' => 'Source (nom)', 'type' => 'text'],
        ['key' => 'ref_source_url', 'label' => 'Source (lien)', 'type' => 'url'],
        ['key' => 'ref_date', 'label' => 'Date de consultation', 'type' => 'date'],
        ['key' => 'ref_note', 'label' => 'Note', 'type' => 'textarea', 'rows' => 2],
        ['key' => 'ref_entrees_valeur', 'label' => 'Entrées par an (15-24 ans)', 'type' => 'number', 'step' => '0.1'],
        ['key' => 'ref_entrees_source_nom', 'label' => 'Entrées : source (nom)', 'type' => 'text'],
        ['key' => 'ref_entrees_source_url', 'label' => 'Entrées : source (lien)', 'type' => 'url'],
        ['key' => 'ref_entrees_date', 'label' => 'Entrées : date de consultation', 'type' => 'date'],
        ['key' => 'ref_entrees_note', 'label' => 'Entrées : note', 'type' => 'textarea', 'rows' => 2],
        ['type' => 'heading', 'label' => 'Statistiques de la communauté et groupes en direct (facultatif)'],
        ['key' => 'stats_endpoint', 'label' => 'Adresse du service de compteurs', 'type' => 'url', 'help' => 'Voir backend/README.md du site d\'origine (Cloudflare Worker). Vide : aucune statistique, les groupes fonctionnent par liens.'],
        ['key' => 'stats_seuil', 'label' => 'Seuil d\'affichage', 'type' => 'number', 'step' => '1', 'min' => '1', 'default' => 30, 'help' => 'Nombre minimal de personnes qui ont trié un film avant d\'afficher son pourcentage.'],
        ['key' => 'stats_demo', 'label' => 'Mode démo', 'type' => 'checkbox', 'check_label' => 'Afficher des données FICTIVES étiquetées « Démo » (présentation à l\'école)', 'help' => 'S\'éteint tout seul dès que l\'adresse du service est remplie. Décoche avant de citer un chiffre.'],
    ];
}

add_action('admin_menu', function () {
    add_submenu_page('edit.php?post_type=cs_film', 'Réglages CinéSwipe', 'Réglages', 'manage_options', 'cineswipe-reglages', 'cs_settings_page');
});

add_action('admin_init', function () {
    register_setting('cs_settings_group', 'cs_settings', [
        'type' => 'array', 'default' => [],
        'sanitize_callback' => function ($input) {
            return cs_sanitize_fields(cs_settings_fields(), wp_slash(is_array($input) ? $input : []));
        },
    ]);
});

function cs_settings_page() {
    if (!current_user_can('manage_options')) { return; }
    echo '<div class="wrap"><h1>Réglages CinéSwipe</h1>';
    settings_errors();
    echo '<form method="post" action="options.php">';
    settings_fields('cs_settings_group');
    cs_render_fields(cs_settings_fields(), function ($f) { return cs_setting($f['key'], $f['default'] ?? ''); }, 'cs_settings');
    submit_button('Enregistrer');
    echo '</form></div>';
}
