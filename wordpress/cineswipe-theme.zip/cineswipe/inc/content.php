<?php
/**
 * Prépare tout ce que les gabarits utilisent (portage de lib/contenu.js) à partir des contenus WordPress.
 * cs_contenu() renvoie un tableau équivalent à l'objet "contenu" du site statique, calculé une fois par requête.
 */
if (!defined('ABSPATH')) { exit; }

function cs_jours_entre($a, $b) {
    $da = new DateTime($a . ' 00:00:00', new DateTimeZone('UTC'));
    $db = new DateTime($b . ' 00:00:00', new DateTimeZone('UTC'));
    return (int) round(($db->getTimestamp() - $da->getTimestamp()) / 86400);
}

function cs_fraicheur($date_iso, $aujourdhui, $seuil) {
    $n = cs_jours_entre($date_iso, $aujourdhui);
    $texte = $n <= 0 ? 'Relevé aujourd\'hui' : ($n === 1 ? 'Relevé hier' : 'Relevé il y a ' . $n . ' jours');
    return ['jours' => $n, 'texte' => $texte, 'ancien' => $n > $seuil];
}

function cs_html_riche($html) {
    return wp_kses_post(wpautop((string) $html));
}

function cs_posts($type, $ordre = 'title') {
    $args = [
        'post_type' => $type, 'post_status' => 'publish', 'numberposts' => -1, 'suppress_filters' => true,
    ];
    if ($ordre === 'menu') { $args['orderby'] = ['menu_order' => 'ASC', 'title' => 'ASC']; }
    else { $args['orderby'] = 'title'; $args['order'] = 'ASC'; }
    return get_posts($args);
}

function cs_poster($post_id) {
    $thumb = get_post_thumbnail_id($post_id);
    if (!$thumb) { return null; }
    $s = wp_get_attachment_image_src($thumb, 'cs-poster-s');
    $m = wp_get_attachment_image_src($thumb, 'cs-poster-m');
    if (!$s || !$m) { return null; }
    $srcset = $s[0] === $m[0] ? $m[0] . ' ' . (int) $m[1] . 'w' : $s[0] . ' ' . (int) $s[1] . 'w, ' . $m[0] . ' ' . (int) $m[1] . 'w';
    return [
        'webpSrcset' => '', 'jpegSrc' => $s[0], 'jpegSrcset' => $srcset,
        'largeur' => (int) $m[1], 'hauteur' => (int) $m[2], 'og' => $m[0],
    ];
}

function cs_contenu() {
    static $cache = null;
    if ($cache !== null) { return $cache; }

    $aujourdhui = cs_aujourdhui();
    $seuil = (int) cs_setting('fraicheur_jours', 14);
    if ($seuil <= 0) { $seuil = 14; }

    /* ---------- Cinémas ---------- */
    $cinemas = [];
    foreach (cs_posts('cs_cinema') as $p) {
        $id = $p->post_name;
        $lat = cs_meta($p->ID, 'lat');
        $lng = cs_meta($p->ID, 'lng');
        $ok = is_numeric($lat) && is_numeric($lng);
        $type = cs_meta($p->ID, 'type', 'circuit');
        $cinemas[$id] = [
            'id' => $id, 'exemple' => cs_meta($p->ID, 'exemple') === '1',
            'nom' => $p->post_title, 'ville' => (string) cs_meta($p->ID, 'ville'), 'adresse' => (string) cs_meta($p->ID, 'adresse'),
            'type' => $type, 'typeLabel' => CS_TYPES_CINEMA[$type] ?? '', 'circuit' => (string) cs_meta($p->ID, 'circuit'),
            'lat' => $ok ? (float) $lat : null, 'lng' => $ok ? (float) $lng : null,
            'site' => (string) cs_meta($p->ID, 'site'),
            'osm' => $ok ? 'https://www.openstreetmap.org/?mlat=' . (float) $lat . '&mlon=' . (float) $lng . '#map=17/' . (float) $lat . '/' . (float) $lng : '',
        ];
    }
    $cinemas_utilises = [];

    /* ---------- Films ---------- */
    $films = [];
    foreach (cs_posts('cs_film') as $p) {
        $slug = $p->post_name;
        $id = $p->ID;
        $m = function ($k, $d = '') use ($id) { return cs_meta($id, $k, $d); };

        $projections = [];
        foreach ((array) get_post_meta($id, 'cs_projections', true) as $pr) {
            $cid = $pr['cinema'] ?? '';
            if (!$cid || !isset($cinemas[$cid])) { continue; }
            $cinemas_utilises[$cid] = true;
            $tp = null;
            if (isset($pr['montant']) && $pr['montant'] !== '' && cs_iso_date($pr['date'] ?? '')) {
                $tp = [
                    'montant' => (float) $pr['montant'], 'montantFr' => cs_prix_fr($pr['montant']), 'type' => (string) $pr['type'],
                    'sourceNom' => (string) $pr['source_nom'], 'sourceUrl' => (string) $pr['source_url'],
                    'date' => $pr['date'], 'dateFr' => cs_date_fr($pr['date']), 'fraicheur' => cs_fraicheur($pr['date'], $aujourdhui, $seuil),
                ];
            }
            $projections[] = [
                'cinemaId' => $cid, 'cinema' => $cinemas[$cid],
                'url' => !empty($pr['url']) ? $pr['url'] : $cinemas[$cid]['site'], 'urlFilm' => !empty($pr['url']),
                'tarif' => $tp,
            ];
        }

        $maison = null;
        if (cs_iso_date($m('maison_verifie_le'))) {
            $titres = [];
            foreach (['t1', 't2'] as $t) {
                if ($m("maison_{$t}_titre") !== '') {
                    $titres[] = ['titre' => (string) $m("maison_{$t}_titre"), 'plateforme' => (string) $m("maison_{$t}_plateforme"), 'pourquoi' => (string) $m("maison_{$t}_pourquoi")];
                }
            }
            $abo = null;
            if ($m('maison_abo_plateforme') !== '' && is_numeric($m('maison_abo_montant')) && cs_iso_date($m('maison_abo_date'))) {
                $abo = [
                    'plateforme' => (string) $m('maison_abo_plateforme'), 'montant' => (float) $m('maison_abo_montant'), 'montantFr' => cs_prix_fr($m('maison_abo_montant')),
                    'sourceNom' => (string) $m('maison_abo_source_nom'), 'sourceUrl' => (string) $m('maison_abo_source_url'), 'dateFr' => cs_date_fr($m('maison_abo_date')),
                ];
            }
            if ($titres) {
                $maison = ['verifieLe' => cs_date_fr($m('maison_verifie_le')), 'sourceNom' => (string) $m('maison_source_nom'), 'sourceUrl' => (string) $m('maison_source_url'), 'titres' => $titres, 'abonnement' => $abo];
            }
        }

        $poster = cs_poster($id);
        $montant = $m('tarif_montant');
        $montant_fr = is_numeric($montant) ? cs_prix_fr($montant) : '';
        $date_tarif = cs_iso_date($m('tarif_date'));
        $sortie = cs_iso_date($m('sortie'));
        $genres = array_values(array_filter(array_map('trim', explode(',', (string) $m('genres'))), 'strlen'));
        $duree = is_numeric($m('duree')) ? (int) $m('duree') : null;
        $cat = $m('categorie', 'nouveau');
        if (!isset(CS_CATEGORIES[$cat])) { $cat = 'nouveau'; }
        $annee = is_numeric($m('annee')) ? (int) $m('annee') : null;
        $url = '/films/' . $slug . '/';
        $tt = (string) $m('tarif_type');
        $pq = (string) $m('verdict_pour_qui');
        $px = (string) $m('verdict_prix');
        $desc = $m('meta_description') !== '' ? (string) $m('meta_description')
            : cs_tronque(cs_fin_de_phrase($pq) . ' ' . cs_fin_de_phrase($px) . ' Tarif ' . $tt . ' constaté : ' . $montant_fr . '.', 155);

        $films[$slug] = [
            'slug' => $slug, 'url' => $url, 'urlAbs' => home_url($url), 'exemple' => $m('exemple') === '1',
            'titre' => $p->post_title, 'titreOriginal' => (string) $m('titre_original'),
            'sortie' => $sortie, 'sortieFr' => $sortie ? cs_date_fr($sortie) : '',
            'duree' => $duree, 'dureeFr' => cs_duree_fr($duree),
            'genres' => $genres, 'realisateur' => (string) $m('realisateur'), 'resume' => (string) $m('resume'),
            'bonPlan' => $m('bon_plan') === '1', 'bandeAnnonce' => (string) $m('bande_annonce'), 'maison' => $maison,
            'categorie' => $cat, 'categorieLabel' => CS_CATEGORIES[$cat], 'annee' => $annee, 'enPlus' => false,
            'projections' => $projections,
            'verdict' => ['pourQui' => $pq, 'prix' => $px, 'pourquoiEnSalle' => (string) $m('verdict_pourquoi')],
            'tarif' => [
                'montant' => is_numeric($montant) ? (float) $montant : null, 'montantFr' => $montant_fr, 'type' => $tt, 'cinema' => (string) $m('tarif_cinema'),
                'sourceNom' => (string) $m('tarif_source_nom'), 'sourceUrl' => (string) $m('tarif_source_url'),
                'date' => $date_tarif, 'dateFr' => $date_tarif ? cs_date_fr($date_tarif) : '',
                'fraicheur' => $date_tarif ? cs_fraicheur($date_tarif, $aujourdhui, $seuil) : null,
            ],
            'reservation' => ['url' => (string) $m('reservation_url'), 'cinema' => $m('reservation_cinema') !== '' ? (string) $m('reservation_cinema') : (string) $m('tarif_cinema')],
            'poster' => $poster, 'afficheAlt' => (string) $m('affiche_alt'), 'afficheCredit' => (string) $m('affiche_credit'),
            'noteHtml' => trim(wp_strip_all_tags($p->post_content)) !== '' ? cs_html_riche($p->post_content) : '',
            'description' => $desc,
            'titreSeo' => cs_tronque($p->post_title . ' : verdict, tarif ' . $tt . ' et réservation', 50),
            'semaineId' => '', 'semaineLabel' => '', 'semaineUrl' => '/', 'semaineBonPlan' => false,
        ];
    }

    /* ---------- Semaines ---------- */
    $brutes = [];
    foreach (cs_posts('cs_semaine') as $p) {
        $date = cs_iso_date(cs_meta($p->ID, 'date'));
        if (!$date) { continue; }
        $lire = function ($cle) use ($p, $films) {
            $out = [];
            foreach ((array) get_post_meta($p->ID, 'cs_' . $cle, true) as $row) {
                $s = $row['film'] ?? '';
                if ($s !== '' && isset($films[$s])) { $out[] = $s; }
            }
            return $out;
        };
        $slugs = $lire('films');
        $plus = $lire('en_plus');
        if (!$slugs) { continue; }
        $brutes[] = ['id' => $p->post_name, 'date' => $date, 'slugs' => $slugs, 'plus' => $plus, 'edito' => trim(wp_strip_all_tags($p->post_content)) !== '' ? cs_html_riche($p->post_content) : ''];
    }
    $publiees = array_values(array_filter($brutes, function ($s) use ($aujourdhui) { return $s['date'] <= $aujourdhui; }));
    usort($publiees, function ($a, $b) { return strcmp($b['date'], $a['date']); });

    // Contexte de semaine pour chaque film publié (la semaine la plus récente l'emporte).
    $films_publies_slugs = [];
    $semaines_meta = [];
    foreach ($publiees as $i => $s) {
        $deck_slugs = array_merge($s['slugs'], $s['plus']);
        $bon_plan = false; $exemple = false;
        foreach ($deck_slugs as $sl) { $bon_plan = $bon_plan || $films[$sl]['bonPlan']; $exemple = $exemple || $films[$sl]['exemple']; }
        $url = $i === 0 ? '/' : '/archives/' . $s['id'] . '/';
        $label = 'Semaine du ' . cs_date_fr($s['date'], false);
        foreach ($deck_slugs as $sl) {
            if (isset($films_publies_slugs[$sl])) { continue; }
            $films_publies_slugs[$sl] = true;
            $films[$sl]['semaineId'] = $s['id'];
            $films[$sl]['semaineLabel'] = $label;
            $films[$sl]['semaineUrl'] = $url;
            $films[$sl]['semaineBonPlan'] = $bon_plan;
            $films[$sl]['enPlus'] = in_array($sl, $s['plus'], true);
        }
        $semaines_meta[$i] = ['url' => $url, 'label' => $label, 'bonPlan' => $bon_plan, 'exemple' => $exemple, 'deck' => $deck_slugs];
    }

    $semaines = [];
    foreach ($publiees as $i => $s) {
        $fin = cs_ajoute_jours($s['date'], 6);
        $mt = $semaines_meta[$i];
        $semaines[] = [
            'id' => $s['id'], 'date' => $s['date'], 'fin' => $fin,
            'dateFr' => cs_date_fr($s['date']), 'finFr' => cs_date_fr($fin),
            'label' => $mt['label'], 'labelLong' => 'Du ' . cs_date_fr($s['date'], false) . ' au ' . cs_date_fr($fin),
            'edito' => $s['edito'],
            'films' => array_map(function ($sl) use ($films) { return $films[$sl]; }, $s['slugs']),
            'enPlus' => array_map(function ($sl) use ($films) { return $films[$sl]; }, $s['plus']),
            'deck' => array_map(function ($sl) use ($films) { return $films[$sl]; }, $mt['deck']),
            'deckHash' => substr(sha1($s['id'] . '|' . implode('|', $mt['deck'])), 0, 6),
            'url' => $mt['url'], 'bonPlan' => $mt['bonPlan'], 'exemple' => $mt['exemple'],
        ];
    }
    $films_publies = [];
    foreach (array_keys($films_publies_slugs) as $sl) { $films_publies[] = $films[$sl]; }

    /* ---------- Cartes, prix de référence, prix moyens ---------- */
    $cartes = [];
    foreach (cs_posts('cs_carte', 'menu') as $p) {
        $type = cs_meta($p->ID, 'type', 'abonnement');
        if ($type === 'abonnement') {
            $d = cs_iso_date(cs_meta($p->ID, 'date'));
            if (!$d || !is_numeric(cs_meta($p->ID, 'prix_mensuel'))) { continue; }
            $pm = (float) cs_meta($p->ID, 'prix_mensuel');
            $cartes[] = ['id' => $p->post_name, 'nom' => $p->post_title, 'type' => 'abonnement', 'circuit' => (string) cs_meta($p->ID, 'circuit'),
                'prixMensuel' => $pm, 'prixMensuelFr' => cs_prix_fr($pm), 'sourceNom' => (string) cs_meta($p->ID, 'source_nom'), 'sourceUrl' => (string) cs_meta($p->ID, 'source_url'), 'dateFr' => cs_date_fr($d)];
        } else {
            $cartes[] = ['id' => $p->post_name, 'nom' => $p->post_title, 'type' => 'reduction', 'tarifType' => (string) cs_meta($p->ID, 'tarif_type')];
        }
    }

    $reference = null;
    $rd = cs_iso_date(cs_setting('ref_date', ''));
    if (is_numeric(cs_setting('ref_montant', '')) && $rd && cs_setting('ref_source_nom', '') !== '') {
        $mt = (float) cs_setting('ref_montant');
        $reference = [
            'montant' => $mt, 'montantFr' => cs_prix_fr($mt), 'libelle' => (string) cs_setting('ref_libelle', 'Prix de la place'),
            'sourceNom' => (string) cs_setting('ref_source_nom'), 'sourceUrl' => (string) cs_setting('ref_source_url'),
            'dateFr' => cs_date_fr($rd), 'note' => (string) cs_setting('ref_note', ''),
        ];
        $ed = cs_iso_date(cs_setting('ref_entrees_date', ''));
        if (is_numeric(cs_setting('ref_entrees_valeur', '')) && $ed) {
            $reference['entreesParAn'] = [
                'valeur' => (float) cs_setting('ref_entrees_valeur'), 'sourceNom' => (string) cs_setting('ref_entrees_source_nom', ''),
                'sourceUrl' => (string) cs_setting('ref_entrees_source_url', ''), 'dateFr' => cs_date_fr($ed), 'note' => (string) cs_setting('ref_entrees_note', ''),
            ];
        }
    }

    $prix_moyens = [];
    foreach (cs_posts('cs_prix', 'menu') as $p) {
        $d = cs_iso_date(cs_meta($p->ID, 'date'));
        if (!$d || !is_numeric(cs_meta($p->ID, 'montant'))) { continue; }
        $mt = (float) cs_meta($p->ID, 'montant');
        $prix_moyens[] = ['libelle' => $p->post_title, 'montant' => $mt, 'montantFr' => cs_prix_fr($mt), 'sourceNom' => (string) cs_meta($p->ID, 'source_nom'),
            'sourceUrl' => (string) cs_meta($p->ID, 'source_url'), 'dateFr' => cs_date_fr($d), 'sources' => (int) cs_meta($p->ID, 'sources', 1), 'note' => (string) cs_meta($p->ID, 'note')];
    }

    /* ---------- Relevés de prix cinéma par cinéma (page Tarifs) ---------- */
    $map = [];
    $ajoute = function ($cinema_nom, $type, $montant, $date, $source_nom, $source_url, $exemple) use (&$map, $aujourdhui, $seuil) {
        if (!$cinema_nom || !$type || !($montant > 0) || !$date) { return; }
        $k = mb_strtolower($cinema_nom . '|' . $type);
        if (isset($map[$k]) && $map[$k]['date'] >= $date) { return; }
        $map[$k] = ['cinema' => $cinema_nom, 'type' => $type, 'montant' => $montant, 'montantFr' => cs_prix_fr($montant), 'date' => $date, 'dateFr' => cs_date_fr($date),
            'fraicheur' => cs_fraicheur($date, $aujourdhui, $seuil), 'sourceNom' => $source_nom, 'sourceUrl' => $source_url, 'exemple' => $exemple];
    };
    foreach ($films_publies as $f) {
        $ajoute($f['tarif']['cinema'], $f['tarif']['type'], $f['tarif']['montant'], $f['tarif']['date'], $f['tarif']['sourceNom'], $f['tarif']['sourceUrl'], $f['exemple']);
        foreach ($f['projections'] as $pr) {
            if ($pr['tarif']) { $ajoute($pr['cinema']['nom'], $pr['tarif']['type'], $pr['tarif']['montant'], $pr['tarif']['date'], $pr['tarif']['sourceNom'], $pr['tarif']['sourceUrl'], $f['exemple']); }
        }
    }
    $releves = array_values($map);
    usort($releves, function ($a, $b) {
        $c = strcoll($a['cinema'], $b['cinema']);
        return $c !== 0 ? $c : ($a['montant'] <=> $b['montant']);
    });

    /* ---------- Données allégées pour le swipe, les groupes et « Où le voir » ---------- */
    $cinema_json = function ($c) {
        return ['id' => $c['id'], 'nom' => $c['nom'], 'ville' => $c['ville'], 'adresse' => $c['adresse'], 'type' => $c['type'], 'circuit' => $c['circuit'],
            'lat' => $c['lat'], 'lng' => $c['lng'], 'site' => $c['site'], 'osm' => $c['osm'], 'exemple' => $c['exemple']];
    };
    $film_json = function ($f) {
        return [
            'slug' => $f['slug'], 'titre' => $f['titre'], 'url' => $f['url'], 'urlAbs' => $f['urlAbs'],
            'genres' => $f['genres'], 'bonPlan' => $f['bonPlan'], 'exemple' => $f['exemple'],
            'categorie' => $f['categorie'], 'categorieLabel' => $f['categorieLabel'], 'annee' => $f['annee'], 'enPlus' => $f['enPlus'],
            'pourQui' => $f['verdict']['pourQui'], 'prix' => $f['verdict']['prix'], 'pourquoi' => $f['verdict']['pourquoiEnSalle'],
            'montant' => $f['tarif']['montant'], 'montantFr' => $f['tarif']['montantFr'], 'tarifType' => $f['tarif']['type'], 'cinema' => $f['reservation']['cinema'],
            'reservationUrl' => $f['reservation']['url'],
            'seances' => array_map(function ($p) {
                return ['c' => $p['cinemaId'], 'u' => $p['url'], 'uf' => $p['urlFilm'], 'm' => $p['tarif'] ? $p['tarif']['montantFr'] : null, 't' => $p['tarif'] ? $p['tarif']['type'] : null];
            }, $f['projections']),
            'poster' => $f['poster'] ? ['webp' => $f['poster']['webpSrcset'], 'src' => $f['poster']['jpegSrc']] : null,
            'afficheAlt' => $f['afficheAlt'],
        ];
    };
    $courante = $semaines ? $semaines[0] : null;
    $archives = array_slice($semaines, 1);
    $swipe = $courante ? array_map($film_json, $courante['deck']) : [];
    $cinemas_swipe = [];
    if ($courante) {
        $ids = [];
        foreach ($courante['deck'] as $f) { foreach ($f['projections'] as $p) { $ids[$p['cinemaId']] = true; } }
        foreach (array_keys($ids) as $cid) { $cinemas_swipe[] = $cinema_json($cinemas[$cid]); }
    }

    /* ---------- Articles ---------- */
    $articles = [];
    foreach (cs_posts('cs_article') as $p) {
        $id = $p->ID;
        $rub = cs_meta($id, 'rubrique', 'ca-vaut-le-prix');
        if (!isset(CS_RUBRIQUES[$rub])) { continue; }
        $d = cs_iso_date(cs_meta($id, 'prix_releves_le'));
        $relu = trim((string) cs_meta($id, 'relu_par'));
        $sources = [];
        foreach ((array) get_post_meta($id, 'cs_sources', true) as $i => $s) {
            $sources[] = ['n' => $i + 1, 'nom' => (string) ($s['nom'] ?? ''), 'url' => (string) ($s['url'] ?? ''), 'note' => (string) ($s['note'] ?? '')];
        }
        $html = cs_html_riche($p->post_content);
        $mots = count(array_filter(preg_split('/\s+/u', wp_strip_all_tags($html))));
        $url = '/articles/' . $p->post_name . '/';
        $articles[] = [
            'slug' => $p->post_name, 'url' => $url, 'urlAbs' => home_url($url), 'titre' => $p->post_title, 'rubrique' => $rub, 'rubriqueNom' => CS_RUBRIQUES[$rub]['nom'],
            'auteur' => (string) cs_meta($id, 'auteur'), 'numero' => (int) cs_meta($id, 'numero', 0),
            'description' => (string) cs_meta($id, 'meta_description'), 'date' => $d, 'dateFr' => $d ? cs_date_fr($d) : '',
            'relecteur' => $relu, 'enRelecture' => $relu === '', 'reponse' => (string) cs_meta($id, 'reponse'),
            'html' => $html, 'sources' => $sources, 'mots' => $mots, 'minutes' => max(1, (int) round($mots / 200)),
        ];
    }
    usort($articles, function ($a, $b) { return $a['numero'] <=> $b['numero']; });

    /* ---------- Chiffres de contexte (page À propos) ---------- */
    $contexte = [];
    foreach (cs_posts('cs_chiffre', 'menu') as $p) {
        $pub = cs_iso_date(cs_meta($p->ID, 'publie'));
        $con = cs_iso_date(cs_meta($p->ID, 'consulte'));
        $contexte[] = [
            'chiffre' => $p->post_title, 'texte' => (string) cs_meta($p->ID, 'texte'),
            'sourceNom' => (string) cs_meta($p->ID, 'source_nom'), 'sourceUrl' => (string) cs_meta($p->ID, 'source_url'),
            'publieFr' => $pub ? cs_date_fr($pub) : '', 'consulteFr' => $con ? cs_date_fr($con) : '',
            'sources' => (int) cs_meta($p->ID, 'sources', 1), 'calcul' => cs_meta($p->ID, 'calcul') === '1', 'note' => (string) cs_meta($p->ID, 'note'),
        ];
    }

    $cinemas_liste = [];
    foreach ($cinemas as $id => $c) { if (isset($cinemas_utilises[$id])) { $cinemas_liste[] = $c; } }
    $a_des_exemples = false;
    foreach ($films_publies as $f) { if ($f['exemple']) { $a_des_exemples = true; } }
    foreach ($cinemas as $c) { if ($c['exemple']) { $a_des_exemples = true; } }

    $cache = [
        'articles' => $articles, 'rubriques' => CS_RUBRIQUES,
        'films' => $films_publies, 'filmsParSlug' => $films,
        'cartes' => $cartes, 'referenceCartes' => $reference, 'prixMoyens' => $prix_moyens, 'releves' => $releves, 'seuilFraicheur' => $seuil,
        'semaines' => $semaines, 'courante' => $courante, 'archives' => $archives, 'swipe' => $swipe, 'cinemasSwipe' => $cinemas_swipe,
        'cinemas' => $cinemas_liste, 'contexte' => $contexte,
        'aDuContenu' => (bool) $courante, 'aDesExemples' => $a_des_exemples,
    ];
    return $cache;
}

/** Retrouve une semaine publiée par son identifiant. */
function cs_semaine_par_id($id) {
    foreach (cs_contenu()['semaines'] as $s) { if ($s['id'] === $id) { return $s; } }
    return null;
}
