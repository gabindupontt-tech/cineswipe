<?php
/**
 * Import du contenu de départ : les films, cinémas, semaine, articles, cartes, prix moyens, chiffres et réglages
 * du site statique d'origine (seed/seed.json) et ses affiches (seed/posters/).
 * Outil > Importer le contenu de départ. Ne remplace jamais un contenu qui existe déjà.
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function () {
    add_submenu_page('edit.php?post_type=cs_film', 'Importer le contenu de départ', 'Importer le contenu de départ', 'manage_options', 'cineswipe-import', 'cs_seed_page');
});

function cs_seed_lien_racine($html) {
    return str_replace(['href="/', "href='/"], ['href="' . untrailingslashit(home_url()) . '/', "href='" . untrailingslashit(home_url()) . '/'], (string) $html);
}

function cs_seed_poster($post_id, $fichier, $alt) {
    $chemin = get_theme_file_path('seed/posters/' . basename($fichier));
    if (!$fichier || !file_exists($chemin)) { return false; }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $tmp = wp_tempnam($fichier);
    if (!$tmp || !copy($chemin, $tmp)) { return false; }
    $att = media_handle_sideload(['name' => basename($fichier), 'tmp_name' => $tmp], $post_id);
    if (is_wp_error($att)) { @unlink($tmp); return false; }
    update_post_meta($att, '_wp_attachment_image_alt', $alt);
    set_post_thumbnail($post_id, $att);
    return true;
}

/** Crée un contenu s'il n'existe pas. Renvoie 'cree', 'existe' ou 'brouillon' (contrôles non passés). */
function cs_seed_post($type, $item, &$rapport) {
    $slug = $item['slug'];
    if (get_page_by_path($slug, OBJECT, $type)) { $rapport[$type]['existe'][] = $slug; return; }
    $id = wp_insert_post([
        'post_type' => $type, 'post_status' => 'publish', 'post_title' => $item['title'], 'post_name' => $slug,
        'post_content' => isset($item['content']) ? cs_seed_lien_racine($item['content']) : '', 'menu_order' => $item['order'] ?? 0,
    ], true);
    if (is_wp_error($id) || !$id) { $rapport[$type]['erreur'][] = $slug; return; }
    foreach ($item['fields'] as $k => $v) { update_post_meta($id, 'cs_' . $k, $v); }
    if (!empty($item['poster'])) { cs_seed_poster($id, $item['poster'], $item['fields']['affiche_alt'] ?? ''); }
    do_action('cs_after_save_' . $type, $id, get_post($id));
    $statut = get_post_status($id);
    if ($statut === 'publish') { $rapport[$type]['cree'][] = $slug; }
    else {
        $rapport[$type]['brouillon'][] = $slug;
        $err = get_transient('cs_err_' . $id . '_' . get_current_user_id());
        if ($err) { $rapport[$type]['messages'][$slug] = $err; delete_transient('cs_err_' . $id . '_' . get_current_user_id()); }
    }
}

function cs_seed_run() {
    $fichier = get_theme_file_path('seed/seed.json');
    if (!file_exists($fichier)) { return null; }
    $seed = json_decode(file_get_contents($fichier), true);
    if (!is_array($seed)) { return null; }
    $rapport = [];

    // Réglages : on ne remplace que ce qui est vide.
    $actuels = get_option('cs_settings', []);
    $actuels = is_array($actuels) ? $actuels : [];
    foreach ($seed['settings'] as $k => $v) {
        if (!isset($actuels[$k]) || $actuels[$k] === '') { $actuels[$k] = $v; }
    }
    update_option('cs_settings', $actuels);

    // Dans l'ordre : les films ont besoin des cinémas, les semaines des films.
    foreach ([['cs_cinema', 'cinemas'], ['cs_film', 'films'], ['cs_semaine', 'semaines'], ['cs_article', 'articles'], ['cs_carte', 'cartes'], ['cs_prix', 'prix'], ['cs_chiffre', 'chiffres']] as $paire) {
        foreach ($seed[$paire[1]] as $item) { cs_seed_post($paire[0], $item, $rapport); }
    }
    $rapport['pages'] = cs_ensure_pages();
    return $rapport;
}

function cs_seed_page() {
    if (!current_user_can('manage_options')) { return; }
    $rapport = null;
    if (isset($_POST['cs_seed']) && check_admin_referer('cs_seed_action')) { $rapport = cs_seed_run(); }
    $noms = ['cs_cinema' => 'Cinémas', 'cs_film' => 'Films', 'cs_semaine' => 'Semaines', 'cs_article' => 'Articles', 'cs_carte' => 'Cartes', 'cs_prix' => 'Prix moyens', 'cs_chiffre' => 'Chiffres de contexte'];
    echo '<div class="wrap"><h1>Importer le contenu de départ</h1>';
    echo '<p>Cet outil crée dans WordPress le contenu du site CinéSwipe d\'origine : les 5 films de la semaine du 28 octobre avec leurs affiches, le cinéma, la semaine, les 4 articles, les cartes, les prix moyens, les chiffres de contexte et les réglages. Il crée aussi les pages du site (Swipe, Groupe, Mes cartes...) et règle la page d\'accueil.</p>';
    echo '<p>Il ne remplace jamais un contenu qui existe déjà : tu peux le relancer sans risque.</p>';
    if ($rapport === null && isset($_POST['cs_seed'])) { echo '<div class="notice notice-error"><p>Le fichier seed/seed.json est introuvable ou illisible.</p></div>'; }
    if (is_array($rapport)) {
        echo '<div class="notice notice-success"><p><strong>Import terminé.</strong></p><ul style="list-style:disc;margin-left:1.5em">';
        foreach ($noms as $t => $n) {
            if (empty($rapport[$t])) { continue; }
            $r = $rapport[$t];
            echo '<li>' . esc_html($n) . ' : ' . count($r['cree'] ?? []) . ' créé(s), ' . count($r['existe'] ?? []) . ' déjà présent(s)';
            if (!empty($r['brouillon'])) { echo ', <strong>' . count($r['brouillon']) . ' enregistré(s) en brouillon</strong> (' . esc_html(implode(', ', $r['brouillon'])) . ')'; }
            if (!empty($r['erreur'])) { echo ', erreur sur ' . esc_html(implode(', ', $r['erreur'])); }
            echo '</li>';
            foreach (($r['messages'] ?? []) as $slug => $msgs) { echo '<li style="margin-left:1.5em">' . esc_html($slug) . ' : ' . esc_html(implode(' / ', $msgs)) . '</li>'; }
        }
        if (!empty($rapport['pages'])) { echo '<li>Pages créées : ' . esc_html(implode(', ', $rapport['pages'])) . '</li>'; }
        echo '</ul><p><a href="' . esc_url(home_url('/')) . '">Voir le site</a></p></div>';
    }
    echo '<form method="post">';
    wp_nonce_field('cs_seed_action');
    echo '<p><button type="submit" name="cs_seed" value="1" class="button button-primary button-hero">Importer le contenu de départ</button></p></form>';
    echo '</div>';
}
