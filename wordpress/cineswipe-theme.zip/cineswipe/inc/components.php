<?php
/**
 * Composants de la charte (portage de _includes/components.njk et newsletter.njk).
 * Ne pas modifier sans regarder la charte graphique.
 */
if (!defined('ABSPATH')) { exit; }

/** Séparateur de sections en vague. $suivante = classe de la section qui suit. */
function cs_wave($suivante = 'sunk', $variante = 1) {
    echo '<div class="wave wave--' . esc_attr($suivante) . '" aria-hidden="true">';
    if ($variante === 1) {
        echo '<svg viewBox="0 0 1440 96" preserveAspectRatio="none" focusable="false"><path d="M0 48C120 12 240 12 360 40s240 52 360 28 240-56 360-40 240 40 360 24V96H0Z"/></svg>';
    } else {
        echo '<svg viewBox="0 0 1440 96" preserveAspectRatio="none" focusable="false"><path d="M0 30C150 70 270 70 420 36S690 4 840 36s300 60 600 6V96H0Z"/></svg>';
    }
    echo '</div>';
}

function cs_chips($film) {
    echo '<ul class="chips" aria-label="Informations sur le film">';
    if ($film['exemple']) { echo '<li class="chip chip--exemple">Exemple à remplacer</li>'; }
    if ($film['categorie'] === 'independant') { echo '<li class="chip chip--indep">Indépendant</li>'; }
    elseif ($film['categorie'] === 'reprise') {
        echo '<li class="chip chip--reprise">Reprise';
        if ($film['annee']) { echo ' <span class="sr-only">de</span> ' . (int) $film['annee']; }
        echo '</li>';
    }
    if ($film['bonPlan']) { echo '<li class="chip chip--bonplan">Bon plan</li>'; }
    foreach ($film['genres'] as $g) { echo '<li class="chip">' . esc_html($g) . '</li>'; }
    if ($film['dureeFr']) { echo '<li class="chip">' . esc_html($film['dureeFr']) . '</li>'; }
    echo '</ul>';
}

function cs_price_badge($film) {
    echo '<p class="price-badge"><span class="price-badge__inner"><span class="price price-badge__montant">' . esc_html($film['tarif']['montantFr']) . '</span> <span class="price-badge__type">' . esc_html($film['tarif']['type']) . '</span></span>';
    echo '<span class="sr-only">Tarif ' . esc_html($film['tarif']['type']) . ' constaté</span></p>';
}

/** Affiche découpée dans un blob (jamais un rectangle). */
function cs_poster_html($film, $sizes = '(min-width: 700px) 340px, 80vw', $forme = 1, $eager = false) {
    echo '<div class="blob blob--' . (int) $forme . '">';
    if ($film['poster']) {
        $p = $film['poster'];
        echo '<picture><img src="' . esc_url($p['jpegSrc']) . '" srcset="' . esc_attr($p['jpegSrcset']) . '" sizes="' . esc_attr($sizes) . '" width="' . (int) $p['largeur'] . '" height="' . (int) $p['hauteur'] . '" alt="' . esc_attr($film['afficheAlt']) . '"' . ($eager ? '' : ' loading="lazy"') . ' decoding="async"></picture>';
    } else {
        echo '<span class="blob__initiale" aria-hidden="true">' . esc_html(mb_substr(trim($film['titre']), 0, 1)) . '</span>';
    }
    echo '</div>';
}

function cs_verdict_lines($film) {
    $v = $film['verdict'];
    echo '<dl class="verdict">';
    echo '<div class="verdict__row"><dt class="label">Pour qui</dt><dd>' . esc_html($v['pourQui']) . '</dd></div>';
    echo '<div class="verdict__row"><dt class="label">Prix</dt><dd>' . esc_html($v['prix']) . '</dd></div>';
    echo '<div class="verdict__row"><dt class="label">Pourquoi en salle</dt><dd>' . esc_html($v['pourquoiEnSalle']) . '</dd></div>';
    echo '</dl>';
}

function cs_verdict_card($film, $forme = 1) {
    echo '<article class="verdict-card" aria-labelledby="titre-' . esc_attr($film['slug']) . '">';
    echo '<div class="verdict-card__media">';
    cs_poster_html($film, '(min-width: 700px) 300px, 70vw', $forme);
    cs_price_badge($film);
    echo '</div><div class="verdict-card__body">';
    cs_chips($film);
    echo '<h3 class="verdict-card__title" id="titre-' . esc_attr($film['slug']) . '">' . esc_html($film['titre']) . '</h3>';
    cs_verdict_lines($film);
    echo '<p class="verdict-card__cta"><a class="btn btn--ghost" href="' . esc_url(cs_url($film['url'])) . '">Voir la fiche<span class="sr-only"> de ' . esc_html($film['titre']) . '</span></a></p>';
    echo '</div></article>';
}

/** Bloc newsletter. $fond = 'base' pour un fond clair, sinon fond creux. $position = repère de mesure. */
function cs_newsletter($fond = 'sunk', $position = 'accueil') {
    $lien = cs_setting('newsletter_lien', '');
    echo '<section class="section ' . ($fond !== 'base' ? 'section--sunk ' : '') . 'newsletter" id="newsletter" aria-labelledby="newsletter-titre"><div class="wrap wrap--narrow">';
    echo '<h2 id="newsletter-titre">La sélection de la semaine, en 30 secondes</h2>';
    echo '<p>Chaque édition sort aussi sur nos pages Instagram et TikTok : les films qui valent le prix, le tarif étudiant et où réserver. Pas d\'adresse e-mail à donner.</p>';
    echo '<p class="newsletter__row">';
    if ($lien) {
        echo '<a class="btn btn--primary" href="' . esc_url($lien) . '" target="_blank" rel="noopener noreferrer" data-track="newsletter_click" data-position="' . esc_attr($position) . '">Recevoir la newsletter<span class="sr-only"> (s\'ouvre dans un nouvel onglet)</span></a>';
    } else {
        echo '<span class="btn btn--primary" aria-disabled="true">Bientôt disponible</span>';
    }
    foreach (cs_reseaux() as $nom => $url) {
        echo '<a class="btn btn--ghost" href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($nom) . '<span class="sr-only"> (s\'ouvre dans un nouvel onglet)</span></a>';
    }
    echo '</p>';
    if (cs_setting('newsletter_lien_simule', '')) { echo '<p class="caption">Démonstration : ce lien est un exemple, la page vers laquelle il mène est simulée.</p>'; }
    echo '</div></section>';
}
